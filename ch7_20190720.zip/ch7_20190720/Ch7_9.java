/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

import java.util.LinkedList;

/**
 *
 * @author howard
 */
public class Ch7_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LinkedList<Integer> list3 = new LinkedList<>();    
        list3.add(100);
        list3.add(50);
        list3.add(60);
        
        list3.offerFirst(80);
        list3.offerLast(10);
        list3.forEach(System.out::println);
        
        System.out.println(list3.peekFirst());
        System.out.println(list3.peekLast());
        System.out.println("size:"+list3.size());
        
           System.out.println(list3.pollFirst());
           System.out.println(list3.pollLast());
          System.out.println("size:"+list3.size());
    }
    
}
