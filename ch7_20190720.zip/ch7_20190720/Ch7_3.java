/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

/**
 *
 * @author howard
 */
public class Ch7_3 {
    
    enum Product{
        Apple,
        Banana,
        Charry
    }
    public static void main(String[] args) {
        Product p3 =  Product.Banana;
        System.out.println(p3.name());
        System.out.println(p3.ordinal());
      Product p4 =  Product.Charry;  
      System.out.println(p4.ordinal());      
//        Product p1 = Product.Charry;
//        Product p2 = Product.Charry;
//        System.out.println(p2 == p1);
//        Product p3 = Product.valueOf("Banana");
//        System.out.println(p3);
//        Product p4 = Product.valueOf("KiWi");
//        System.out.println(p4);
//       Product[] pros = Product.values();
//        for (Product ps :pros){
//            System.out.println(ps);
//        }
     /*  switch(p1){
           case Apple:
               System.out.println("蘋果");
               break;
           case Banana:
                  System.out.println("香蕉");
               break;
           case Charry:
                  System.out.println("櫻桃");
               break;
       }*/
        
        
    }
    
}
