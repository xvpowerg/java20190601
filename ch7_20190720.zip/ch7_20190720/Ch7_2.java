/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
/**
 *
 * @author howard
 */
public class Ch7_2 {       
      static String paserCharArray(char[] array,Function<char[],String> func){
          return func.apply(array);
      }    
     static String charArrayToString(char[] array){
         StringBuffer sbf = new StringBuffer();
                for (char c : array){
                    sbf.append(c);
                }
         return sbf.toString();
     }
     
     static void filter(int[] arrays,Predicate<Integer> pre){
         for (int v : arrays){
            if (pre.test(v)){
                System.out.println(v);
             }
         }      
     }
     
     static int getValue(int[] array,int index,Supplier<Integer> defVlaue){
         if (index < array.length ){
             return array[index];
         }
         return defVlaue.get();
     }
   static <T> T getValue2(T[] array,int index,Supplier<T> defVlaue){
         if (index < array.length ){
             return array[index];
         }
         return defVlaue.get();
     }
   static void changeArray(String[] array,UnaryOperator<String> uo){
       for (int i =0; i < array.length;i++){
           array[i] = uo.apply(array[i]);
       }
       new String();
   }
   
   static String charArrayToString(char[]array,Function<char[],String> fun){
       return fun.apply(array);
   }
     
    public static void main(String[] args) {      
         /* Consumer<T>  accept( T t)
    Function<T,R>  R apply(T t)
    Predicate<T>  boolean test(T t)
    Supplier<T>    T      get()
    UnaryOperator<T>      T apply(T t)
     */
 //Function<T,R>  R apply(T t)
 //method reference 使用方式 
    char[] array = {'A','p','p','l','e'};
    String str = paserCharArray(array,Ch7_2::charArrayToString);
    System.out.println(str);
  //Predicate
  int[] dateTime = {20191021,20190718,20190919,20190513,20190417};
  filter(dateTime,(date)->date > 20190613 );
  
   int date = getValue(dateTime,1,()->{return 19770101;});     
     System.out.println(date);
    date = getValue(dateTime,10,()->{return 19770101;});     
     System.out.println(date);  
     String[] names = {"Ken","Vivin","Lindy"};
     
     String name1 = getValue2(names,2,()->"Empty");
     System.out.println(name1);
     String name2 = getValue2(names,100,()->"Empty");
     System.out.println(name2);  
    
     Integer[] dateTime2 = {20191021,20190718,20190919,20190513,20190417};
    int name3 = getValue2(dateTime2,100,()->0);
    
     String[] names2 = {"Ken","Vivin","Lindy"};
     
        changeArray(names2,(st)->st.toLowerCase());
        for (String v : names2){
            System.out.print(v+" ");
        }
        
        char[] c1 = {'A','B'};
       System.out.println(charArrayToString(c1,String::new));
    }
    
}
