/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;
import java.util.ArrayList;
public class Ch7_6 {
    public static void main(String[] args) {
        Student st1 = new Student("Ken",81);
        Student st2 = new Student("Vivin",92);
        Student st3 = new Student("Lindy",41);
        Student st4 = new Student("Join",73);
        
        Student st5 = new Student("Ken",81);  
        
        System.out.println(st1.equals(st5));
        
        ArrayList<Student> list = new ArrayList<>(100);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.forEach(System.out::println);
        System.out.println("==================");
        list.remove(st5);
        list.forEach(System.out::println); 
        
    }
    
}
