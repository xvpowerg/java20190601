/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;
import java.util.Stack;

public class Ch7_8 {

    public static void main(String[] args) {
      Stack<String> pageTack = new Stack<>();
      pageTack.push("Page1");
      pageTack.push("Page2");
      pageTack.push("Page3");
      
      while(!pageTack.empty()){
          System.out.println(pageTack.pop());
      }
 
    }
    
}
