/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

/**
 *
 * @author howard
 */
public class Student {
    private String name;
    private int score;

    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }
    public String toString(){
        return "Name:"+name+" Score:"+score;
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Student == false){
            return false;
        }
        Student tmp = (Student)obj;
        
        return this.getName().equals(tmp.getName()) &&
                this.getScore() == tmp.getScore();
    }
}
