/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

import java.util.LinkedList;
public class Ch7_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        list.add(8);
        list.add(9);
        list.add(15);
        list.add(3);
       // list.forEach(System.out::println);
       int v1 = list.remove();
       System.out.println(v1);
       int v2 = list.poll();
       System.out.println(v2);
       System.out.println("size:"+list.size()); 
         list.remove();
         list.poll();
          System.out.println("size:"+list.size());   
         System.out.println("poll:"+list.poll());  
         //java.util.NoSuchElementException
         //System.out.println("remove:"+list.remove()); 
           System.out.println("==============");
        LinkedList<Integer> list2 = new LinkedList<>();  
        list2.add(100);
        list2.add(50);
        list2.add(60);
        list2.add(120);
        Integer value = null;
         while( (value = list2.poll())!= null   ){
             System.out.print(value+" ");
         }
         System.out.println("Size:"+list2.size());
         
       LinkedList<Integer> list3 = new LinkedList<>();    
        list3.add(100);
        list3.add(50);
        list3.add(60); 
        //list3.clear();
        System.out.println("Peek:"+list3.peek());
        System.out.println("Size:"+list3.size());
          System.out.println("element:"+list3.element());
        System.out.println("Size:"+list3.size());
    }
    
}

