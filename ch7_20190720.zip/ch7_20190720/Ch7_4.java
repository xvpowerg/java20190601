/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

/**
 *
 * @author howard
 */
public class Ch7_4 {

   enum FileOption{
       Copy("複製"),
       Move("移動"),
       Delete("刪除");
     private String msg;
     private FileOption(String msg){
         this.msg = msg;
     }
     public String toString(){
         return msg;
     }  
   }
    public static void main(String[] args) {
        FileOption fo = FileOption.Copy;
        System.out.println(fo);
       FileOption fo2 = FileOption.Delete;
        System.out.println(fo2);
    }
    
}
