/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.BinaryOperator;
/**
 *
 * @author howard
 */
public class Ch7_1 {
    
    //Consumer
    static <T> void printValue(T value,Consumer<T> consumer){
        consumer.accept(value);
    }    
    //Consumer
    static void stringCharSum(String str){
        System.out.print(str+"字元總和:");
        int sum = 0;
        char[] charArray  =str.toCharArray();
        for (char c : charArray){
           sum += c;
         }
        System.out.print(sum);
    }
    
    //Function
    static int sumIntAndString(int number1,String nmaue2,Function<String,Integer> f1){
        return f1.apply(nmaue2) + number1;
    }
    //T 定義傳入類型
    //R 定義回傳類型
    static <T,R> R sumDiffType(T number1,R number2,
                                    Function<T,R> f1,
                                    BinaryOperator<R> bo){
        return bo.apply(f1.apply(number1), number2);
    }
    public static void main(String[] args) {
    //    Consumer<T>  accept(T t)
   printValue("Ken",(str)->{System.out.println("Name:"+str);  });   
   //因為只有一各參數使用lamdb時可以不用加上()  
   //只有一條命令時可不加上{},注意無{} 時不可加上; 案例如下:
  Ch7_1.<Integer>printValue(25,v->System.out.println(v+5) );
    printValue("Join",n->{     System.out.print(n+"字元總和:");
                            int sum = 0;
                            char[] charArray  =n.toCharArray();
                            for (char c : charArray){
                                sum += c;
                            }
                             System.out.print(sum);
                            });  
  //Consumer method reference 使用方式     
    printValue("Join",Ch7_1::stringCharSum);
      System.out.println("=====================");
    //Function
   int sum =  sumIntAndString(10,"15",(str)->Integer.parseInt(str));
    System.out.println(sum);
    
    float v1 =sumDiffType("7.5",3.8f,(str)->Float.parseFloat(str),(f1,f2)->f1 +f2);
    System.out.print(v1);
    sumDiffType("7.5",3.8f,Float::parseFloat,(f1,f2)->f1 +f2);     
    sumDiffType("85",200,(str)->Integer.parseInt(str),(f1,f2)->f1 +f2);
    sumDiffType("85",200,Integer::parseInt,(f1,f2)->f1 +f2);
    
 /* Consumer<T>  accept( T t)
    Function<T,R>  R apply(T t)
    Predicate<T>  boolean test(T t)
    Supplier<T>    T      get()
    UnaryOperator<T>      T apply(T t)
     */
 
 
    
    }
    
}
