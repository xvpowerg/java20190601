/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190720;

/**
 *
 * @author howard
 */
import java.util.ArrayList;
import java.util.Comparator;
public class Ch7_5 {


    public static void main(String[] args) {
        //List 
        //Set
        //Map        
        ArrayList<String> list = new ArrayList<>(100);
        list.add("Ken");
        list.add("Viivn");
        list.add("Lindy");
        
        list.add(1, "Iris");
        list.forEach(System.out::println);
        System.out.println("=============");
        ArrayList<String> data = new ArrayList<>();
        data.add("Howard");
        data.add("Join");      
        data.add("Stvie");
        list.addAll(data);
        list.forEach(System.out::println);
        System.out.println(list.contains("Join"));
        System.out.println(list.contains("Kobe"));
        
        int index = list.indexOf("Howard");
        System.out.println(index);
        index = list.indexOf("Mine");
          System.out.println(index);
         // list.clear();
          System.out.println(list.isEmpty());
          if (list.isEmpty()){
              System.out.println("請輸入資料!");
          }
            System.out.println("===============");
          list.removeIf((s)->s.length() <= 4);
          list.forEach(System.out::println);
            System.out.println("===============");
          list.replaceAll((s)->s.toUpperCase());
           list.forEach(System.out::println);
           
          list.set(0, "Ben");
          System.out.println("===============");
          list.forEach(System.out::println);    
          
         System.out.println("===============");
          Comparator<String> cmp = Comparator.comparing(s->s);
          list.sort(cmp);
          list.forEach(System.out::println);
          
        /*for (String v : list){
            System.out.print(v+" ");
        }
        System.out.println("");
        for (int i =0; i < list.size();i++){
            System.out.print(list.get(i)+" ");
        }
          System.out.println("");
         list.forEach(System.out::println);*/
         
         
         
    }
    
}

