/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;
import java.util.stream.Stream;
public class Ch10_3 {
    public static void main(String[] args) {
       
        Stream<String> stream = 
                Stream.of("Kne","Vivin","Lindy","Iris","Howard");
        //1 一個stream串只能呼叫一次方法
          //stream.filter((c)->true);       
          //stream.limit(10);
        
        //2 Stream 有2種類型 
            //Terminal 終端的 forEach
            //Lazy 惰性的 filter 
            //有呼叫終端的
//         stream.filter((name)->name.length() > 3).
//                 peek((v)->System.out.println("peek:"+v)).
//                 forEach(System.out::println);
         //惰性的 未呼叫終端 沒有任何方法執行
//         stream.filter((name)->name.length() > 3  ).
//                 peek((v)->System.out.println("peek:"+v));            
        //3 Stream永遠不會改變來源的資料
       
        
        //常用Stream 方法
//        boolean allMatch1 = stream.allMatch((n)->n.length() > 2);
//        System.out.println(allMatch1);
//         boolean allMatch2 = stream.allMatch((n)->n.length() >3);
//           System.out.println(allMatch2);
//          boolean anyMatch1 =  stream.anyMatch((name)->name.indexOf("r") > 0);
//           System.out.println(anyMatch1);
//            boolean anyMatch2 =  stream.anyMatch((name)->name.indexOf("x") > 0);
//           System.out.println(anyMatch2);
//            boolean noneMatch1 = 
//                    stream.noneMatch((name)->name.indexOf("x") > 0);
//            System.out.println(noneMatch1);
           // boolean noneMatch2 = stream.noneMatch((name)->name.indexOf("n") > 0);
             // System.out.println(noneMatch2);
             //短路
             //allMatch 只要一個為false就不繼續 回傳true
//             boolean allMatch1 = stream.
//                     peek(System.out::println).
//                     allMatch((n)->n.length() > 3);
//             System.out.println(allMatch1);
             // noneMatch 只要一個為true就不繼續 回傳false
//            boolean noneMatch2 = stream.peek(System.out::println).
//                     noneMatch((n)->n.length() > 4);
//              System.out.println(noneMatch2); 
             // anyMatch 只要一個為true就不繼續判斷 回傳true
          boolean anyMatch = 
                  stream.peek(System.out::println).anyMatch((n)->n.length() > 3);
          System.out.println(anyMatch);
             
    }
    
}
