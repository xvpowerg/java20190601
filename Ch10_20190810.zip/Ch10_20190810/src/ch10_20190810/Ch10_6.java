/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;

import java.util.Optional;
import java.util.Random;

/**
 *
 * @author howard
 */
public class Ch10_6 {
    static String getString(){
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i =1;i<=5;i++){
            int value =  random.nextInt(26)+'A';
            sb.append((char)value);
        }
        return sb.toString();
    }
    public static void main(String[] args) {
        
        Optional<String> opStr = Optional.empty();        
        if (opStr.isPresent()){
            System.out.println(opStr.get());
        }
        
//        String name = null;
//        Optional<String> opStr2 = Optional.of(name);
        
        String name2 = null;
        Optional<String> opStr3 = Optional.ofNullable(name2);
        
         String name3 = "Lindy";
        Optional<String> opStr4 = Optional.ofNullable(name3);          
        opStr4.ifPresent((n)->{System.out.println(n);});
        
        String  elseValue =  opStr4.orElse("Empty");
        System.out.println(elseValue);
            elseValue =  opStr3.orElse("Empty");
       System.out.println(elseValue);
         System.out.println("=========================");  
    String orElseGet =   opStr4.orElseGet(Ch10_6::getString);
       System.out.println(orElseGet);
        orElseGet =  opStr3.orElseGet(Ch10_6::getString);
       System.out.println(orElseGet);
    System.out.println("=========================");         
       String orElseThrow =  opStr4.orElseThrow(()->new IllegalArgumentException("姓名不可為null!"));
       System.out.println(orElseThrow);
        opStr3.orElseThrow(()->new IllegalArgumentException("姓名不可為null!"));
    }
    
}
