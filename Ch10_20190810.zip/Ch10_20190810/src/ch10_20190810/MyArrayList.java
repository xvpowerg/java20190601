/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.stream.Stream;
public class MyArrayList<T> implements Iterable<T> {
    private int capacity = 100;
    private int currentIndex = -1;
     private  Object[] data = null; 
     
   private MyArrayList(Object[] newData,int capacity,int currentIndex){
       this.data = newData;       
       this.capacity = capacity;
       this.currentIndex = currentIndex;
   }  
   public MyArrayList(){        
     data= new Object[capacity];
    } 
    public MyArrayList(int capacity){
        this.capacity  = capacity;
        data=  new Object[capacity];        
    }
  
    private class MyIterator<T> implements Iterator<T>{
        private MyArrayList<T> list;
        private int currnetIndex = -1;
        public MyIterator(MyArrayList<T> list){
            this.list = list;
        }
        public boolean hasNext(){
            return currnetIndex < list.size() - 1;
        }
        public T next(){
            return list.get(++currnetIndex);
        }
    }
    
    public Iterator<T> iterator(){
        return new MyIterator(this);
    }
    
    public MyArrayList<T> sort(Comparator<T> comp){  
              Object[] tmpData =  Arrays.copyOf(data, this.size());
              Arrays.sort((T[])tmpData, comp);       
            // Arrays.sort((T[])data, 0, this.size(), comp);
        return new MyArrayList(tmpData,this.capacity,this.currentIndex);
       // return new MyArrayList(data,this.capacity,this.currentIndex);
    }
    public void add(T value){     
         currentIndex++;
         //capacity >> 1 除2的意思
        if ( currentIndex >  (capacity >> 1)  ){
            //讓我的陣列變大 為capacity的2倍
            capacity <<= 1;
          //  System.out.println(capacity);      
           data = Arrays.copyOf(data, capacity);
         //  System.out.println(data.length);  
        }
        data[currentIndex] = value;
    }
    public T get(int index){     
        if (index > currentIndex ){
            throw new IndexOutOfBoundsException("index超過目前索引");
        }
        //if (index)
        //如果index 是 超過 currentIndex 就拋出IndexOutOfBoundsException 例外        
        return (T)data[index];
    }
    public int size(){
        return currentIndex + 1;
    }
    
    public Stream<T> stream(){
        return Arrays.stream((T[])data, 0, size());
    }
    
}
