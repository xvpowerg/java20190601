/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;
import java.util.ArrayList;
public class Ch10_7 {

    public static void main(String[] args) {
      ArrayList<String> list = new ArrayList<>(); 
      list.add("Join");
      list.add("Lindy");
      list.add("Sean");
      list.add("Vivin");
      list.add("Howard");  
      
      //需求 請幫我算出長度大於4的姓名數量
//     long count =  list.stream().filter((n)->n.length()>4 ).count();
//     System.out.println(count);
     
     //list.stream().map((n)->n.length()).forEach(System.out::println);
//     int sum =   list.stream().mapToInt((n)->n.length()).sum();
//     System.out.println(sum);


     
    }
    
}
