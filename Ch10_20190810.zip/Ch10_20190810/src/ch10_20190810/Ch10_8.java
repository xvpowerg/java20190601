/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;

import java.util.ArrayList;
import java.util.OptionalDouble;

/**
 *
 * @author howard
 */
public class Ch10_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArrayList<Student> list = new ArrayList();
        list.add(new Student("Ken",20));
        list.add(new Student("Vivin",31));
        list.add(new Student("Lindy",32));
        list.add(new Student("Ken",18));
        OptionalDouble avg = 
                list.stream().mapToInt((st)->st.getAge()).average();
        System.out.println(avg.getAsDouble());
        
        
    }
    
}
