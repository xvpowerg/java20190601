/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;
import java.util.Comparator;
public class Ch10_1<T> {       
    public static void main(String[] args) {
//     MyArrayList<String> list = new MyArrayList<>(5);
//     list.add("Ken");
//     list.add("Vivin");
//     list.add("Lindy");
//     list.add("Sean");
//     list.add("Tank");
//     list.add("Tom");
//
//     System.out.println(list.get(0));
//     System.out.println(list.get(1));
//    System.out.println(list.get(2));
     
      MyArrayList<Integer> list2 = new MyArrayList<>(5);
      list2.add(20);
      list2.add(5);
      list2.add(7);
      list2.add(8);
      
   MyArrayList newMyList = list2.sort(
           Comparator.<Integer,Integer>comparing(v->{        
       return v;}));
  

   
//   for(int i =0;i<list2.size();i++){
//       System.out.println(list2.get(i));
//   }
//  System.out.println("===================");
//   for(int i =0;i<newMyList.size();i++){
//       System.out.println(newMyList.get(i));
//   }
      
    }
    
}
