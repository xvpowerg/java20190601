/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;

/**
 *
 * @author howard
 */
public class Ch10_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       MyArrayList<Integer> list2 = new MyArrayList<>(5);
      list2.add(20);
      list2.add(5);
      list2.add(7);
      list2.add(8);
      list2.add(6);
      list2.add(9);
      list2.add(11);
//      for (int v :list2 ){
//          System.out.println(v);
//      }
  list2.stream().forEach(System.out::println);
      
      
    }
    
}
