/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;

import java.util.Optional;

/**
 *
 * @author howard
 */
public class Ch10_5 {
    public static void main(String[] args) {
        
        Student st1 = new Student();
        st1.setAge(20);
        Optional<String> optionalName =  st1.getName();
        boolean errName = true;
        if (optionalName.isPresent()){
            String name = optionalName.get();
            if (name.length() < 10 && name.length() >1){
                   System.out.println(name);
                   errName = false;
            }            
        }
        if (errName){
            System.out.println("錯誤的資訊");
        }
//        if (st1.getName() != null && st1.getName().length() < 10 && st1.getName().length() > 1){
//            System.out.println(st1.getName());
//        }else{
//            System.out.println("錯誤資訊");
//        }
        
        
        
        
    }
    
}
