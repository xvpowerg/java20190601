/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190810;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

public class Ch10_4 {
    public static void main(String[] args) {
       Stream<String> stream = 
                Stream.of("Ken","Vivin","Lindy","Iris","Howard");
       //long count = stream.count();
    //  System.out.println(count);
    Stream<String> stream2 = 
                Stream.of("Ken","Ken","Vivin","Ken","Howard");
    //distinct 過濾Stream重複內容
    //stream2.distinct().forEach(System.out::println);
    //  Optional<String>   op1 = stream.findAny();
    Optional<String>   op1 = stream.parallel().findAny();
    System.out.println(op1.get());
//    Optional<String>   op2 =stream.findFirst();
//    System.out.println(op2.get());
  Stream<Integer> stream3 = 
                Stream.of(20,7,8,11,5,2);
    //stream3.parallel().forEach(System.out::println);
    //forEachOrdered parallel時維護Stream的順序
      //stream3.parallel().forEachOrdered(System.out::println);
      
      //stream3.limit(2).forEach(System.out::println);
      //stream3.skip(2).forEach(System.out::println);
      Optional<Integer> maxOptional = stream3.max(Comparator.comparing((v)->v));
      System.out.println(maxOptional.get());      
    }
    
}
