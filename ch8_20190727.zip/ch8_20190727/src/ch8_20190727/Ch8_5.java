/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author howard
 */
public class Ch8_5 {

    public static void main(String[] args) {
      
        Map<Integer,String> map = new HashMap<>();
        map.put(1, "a");
        map.put(2, "b");
        map.put(3, "b");
        
        //合併newValue4因為key在
       String value1 =   map.merge(1, "newValue", (oldV,newV)->oldV+newV);
       System.out.println(value1);
       map.forEach((k,v)->{System.out.println(k+":"+v);});
      System.out.println("===========");
      map.merge(2, "newValue2", (oldV,newV)->null);//刪除因為回傳null
       map.forEach((k,v)->{System.out.println(k+":"+v);});
          System.out.println("===========");
      map.merge(4, "newValue4", (oldV,newV)->oldV + newV);//新增newValue4因為key不在
      map.forEach((k,v)->{System.out.println(k+":"+v);});
    }
    
}
