/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;
import java.util.HashMap;
/**
 *
 * @author howard
 */
public class Ch8_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       HashMap<String,Integer> map = new HashMap<>();
        map.put("A",93);
        map.put("B",85);
        map.put("C",67);
        map.put("E",71);
        //假設Key存在 會不會執行 mappingFunction
          //會執行 mappingFunction 且將相同key的value覆蓋
        map.compute("B", (k,v)->{  
            System.out.println("Key存在 mappingFunction");
            return 51;  });
        System.out.println(map);
        //key如果存在computeIfAbsent 不執行mappingFunction
        map.computeIfAbsent("C",(k)->{
                                   System.out.println("Key存在 mappingFunction"); 
                                    return 96;
                                    });
           System.out.println(map);
        //會執行 mappingFunction 且將相同key的value覆蓋 
        map.computeIfPresent("E", (k,v)->{
                                System.out.println("Key存在 mappingFunction"); 
                                return 62;
                                });
        System.out.println(map);
        
       //假設Key不存在 會不會執行 mappingFunction
       //會執行 mappingFunction  新增一組key與value的對應關係
        map.compute("QW", (k,v)->{
             System.out.println("Key不存在 mappingFunction"); 
            return 93;});
        System.out.println(map);     
       //會執行 mappingFunction  新增一組key與value的對應關係
        map.computeIfAbsent("ER", (k)->{
             System.out.println("Key不存在 mappingFunction");  
            return 94;});
         System.out.println(map);  
        //不會執行 mappingFunction 
        map.computeIfPresent("TY", (k,v)->{
        System.out.println("Key不存在 mappingFunction");  
        return 25;
        });
        System.out.println(map);  
        
        /*
        
       假設我有一群Employee
        請幫我用年齡分組
        Employee Ken 10
        Employee Iris 20
        Employee Vivin 10
        Employee Lindy 20
        
        map.get(10)->>Ken Vivin
        map.get(20)->>Iris Lindy
        
        
        
        
        */
                
                
                
        
        
    }
    
}
