/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;
import java.util.TreeSet;
public class Ch8_3 {
    public static void main(String[] args) {
        Employee emp1 = new Employee("Ken",25,51);
        Employee emp2 = new Employee("Vivin",18,95);
        Employee emp3 = new Employee("Lindy",31,75);
        Employee emp4 = new Employee("Lindy",25,85);
        Employee emp5 = new Employee("Iris",25,85);
        TreeSet<Employee> treeSet = new TreeSet<>();
        treeSet.add(emp1);
        treeSet.add(emp2);
        treeSet.add(emp3);
        treeSet.add(emp4);
        treeSet.add(emp5);
        treeSet.forEach(System.out::println);
        
    }
    
}

