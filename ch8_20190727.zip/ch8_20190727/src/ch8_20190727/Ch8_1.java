/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;
import java.util.HashSet;
public class Ch8_1 {
    public static void main(String[] args) {
    
//        HashSet<String> nameSet = new HashSet<>();
//        nameSet.add("Ken");
//        nameSet.add("Vivin");
//        nameSet.add("Lindy");
//        nameSet.add("Ken");        
//        nameSet.forEach((v)->System.out.println(v));
        Employee emp1 = new Employee("Ken",25,51);
        Employee emp2 = new Employee("Vivin",18,95);
        Employee emp3 = new Employee("Vivin",18,95);
        Employee emp4 = new Employee("Lindy",31,75);
        System.out.println(emp2.equals(emp3));
        //HashSet 會先使用hashCode比較 在使用equals
        HashSet<Employee> set = new HashSet<>();
        set.add(emp1);
        set.add(emp2);
        set.add(emp3);
        set.add(emp4);
        set.forEach(System.out::println);
    }
    
}

