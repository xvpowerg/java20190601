/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;

import java.util.SortedSet;
import java.util.TreeSet;
public class Ch8_2 {

    public static void main(String[] args) {
       TreeSet<Integer> treeSet = new TreeSet<>();
       treeSet.add(10);
       treeSet.add(5);
       treeSet.add(1);
       treeSet.add(7);
       treeSet.add(3);
       
       treeSet.forEach((v)->System.out.print(v+" "));
       System.out.println();
        System.out.println(treeSet.first());
        System.out.println(treeSet.last());
          System.out.println("=====================");
        System.out.println(treeSet.ceiling(4));
        System.out.println(treeSet.higher(4));
         System.out.println("=====================");
        System.out.println(treeSet.ceiling(5));//?>=5
        System.out.println(treeSet.higher(5));//>5
         System.out.println("=====================");
       System.out.println( treeSet.floor(3)); //? <= 3
       System.out.println( treeSet.lower(3));//? < 3
        System.out.println("=====================");
      System.out.println( treeSet.floor(1)); //? <= 1
       System.out.println( treeSet.lower(1));//? < 1 
      //以上ceiling higher floor lower 只要無法找到配對的元素就回傳null
      
     SortedSet<Integer> subSet1 =  treeSet.subSet(3, 7);
     subSet1.forEach((v)->System.out.print(v+" "));
       System.out.println("=====================");
     //如果想要1 3 5 7
       SortedSet<Integer> subSet2 = treeSet.subSet(1,10);
       subSet2.forEach((v)->System.out.print(v+" "));
      System.out.println("=====================");    
       SortedSet<Integer> subSet3 = treeSet.subSet(3, true, 7, true);
         subSet3.forEach((v)->System.out.print(v+" "));
      
    }
    
}
