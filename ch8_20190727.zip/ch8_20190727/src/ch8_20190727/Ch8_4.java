/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190727;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
public class Ch8_4 {
    public static void main(String[] args) {
        HashMap<String,Integer> hashMap  = new HashMap<>();
        hashMap.put("Ken", 71);
        hashMap.put("Lindy", 74);
        hashMap.put("Join", 31);
        hashMap.put("Vivin", 83);         
        hashMap.put("Join", 75);
        
       hashMap.forEach((k,v)->System.out.println(k+":"+v));
        
       System.out.println(hashMap.containsKey("Join"));
       System.out.println(hashMap.containsKey("Iris"));
       System.out.println(hashMap.containsValue(31));
       System.out.println(hashMap.containsValue(83)); 
       
      System.out.println(hashMap.get("Vivin"));
      System.out.println(hashMap.getOrDefault("Iris", -1));
      hashMap.putIfAbsent("Sean", 75);
      System.out.println(hashMap.get("Sean"));
         hashMap.putIfAbsent("Vivin", 21);
      System.out.println(hashMap.get("Vivin"));
      
      Set<Entry<String,Integer>> entrySet =  hashMap.entrySet();
      entrySet.forEach((entry)->{
         System.out.println(entry.getKey()+":"+entry.getValue());      
      });
      
      
      
    }
    
}
