/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.pm;

public class Product  {
    private String name;
    private int price;
    //製造日期
    private int mfd;

    public Product(String name, int price, int mfd) {
        this.name = name;
        this.price = price;
        this.mfd = mfd;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getMfd() {
        return mfd;
    }
    
    
    public String toString(){
        return "品名:"+this.getName()+
              " 價格:"+this.getPrice()+
              " 出廠日期:"+this.getMfd();        
    }
    
    public static void main(String[] args){
        Product p1 = new Product("iPhone",10,20190711);
        System.out.println(p1);
    }
}
