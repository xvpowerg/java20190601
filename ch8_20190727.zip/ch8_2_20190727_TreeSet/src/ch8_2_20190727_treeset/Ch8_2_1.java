/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_2_20190727_treeset;
import tw.com.pm.Product;
import java.util.TreeSet;
public class Ch8_2_1 {
    
    private static class MyProduct extends Product implements Comparable<MyProduct>{
            public MyProduct(String name,int price,int mdf){
                super(name,price,mdf);
            }
           public int compareTo(MyProduct mp){
                if (this.getPrice() > mp.getPrice()){
                    return 1;
                }else if(this.getPrice() < mp.getPrice()){
                        return -1;
                }else if(this.getMfd() > mp.getMfd()){
                        return 1;
                }else if(this.getMfd() < mp.getMfd()){
                    return -1;
                }                
               return this.getName().compareTo(mp.getName());
           }
    }
    
    
    
    
    public static void main(String[] args) {
        Product p1 = new MyProduct("iPhone7",25000,20180521);
        Product p2 = new MyProduct("iPhone8",37000,20190613);
        Product p3 = new MyProduct("new iPad",37000,20190425);
        Product p4 = new MyProduct("Htc Vivie",25000,20190613);
        TreeSet<Product> trSet = new TreeSet<>();
        
        trSet.add(p1);
        trSet.add(p2);
        trSet.add(p3);
        trSet.add(p4);
        
        trSet.forEach(System.out::println);
        
        
        
    }
    
}
