/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_2_20190727_treeset;

import java.util.TreeSet;
import tw.com.pm.Product;
import java.util.Comparator;
/**
 *
 * @author howard
 */
public class Ch8_2_2 {
    
    private static class ProductComparator implements Comparator<Product>{
        public int compare(Product p1,Product p2){
            if (p1.getPrice() > p2.getPrice()){
                return 1;
            }else if(p1.getPrice() < p2.getPrice()){
                return -1;
            }else if(p1.getMfd() > p2.getMfd()){
                return 1;
            }else if(p1.getMfd() < p2.getMfd()){
                return -1;
            }
             return p1.getName().compareTo(p2.getName());
        }
    }
    
    
    private static int productCmpMethod(Product p1,Product p2){
        int result = p1.getPrice() - p2.getPrice();
        if (result != 0){
            return result;
        }
        result = p1.getMfd() - p2.getMfd();        
        if (result != 0){
            return result;
        }
        return p1.getName().compareTo(p2.getName());
    }
    public static void main(String[] args) {
        Product p1 = new Product("iPhone7",25000,20180521);
        Product p2 = new Product("iPhone8",37000,20190613);
        Product p3 = new Product("new iPad",37000,20190425);
        Product p4 = new Product("Htc Vivie",25000,20190613);
        
        ProductComparator proCmp = new  ProductComparator();
        //TreeSet<Product> trSet = new TreeSet<>(proCmp);
//        TreeSet<Product> trSet = new TreeSet<>(new Comparator<Product>(){
//            public int compare(Product p1,Product p2){
//                    if (p1.getPrice() > p2.getPrice()){
//                        return 1;
//                    }else if(p1.getPrice() < p2.getPrice()){
//                        return -1;
//                    }else if(p1.getMfd() > p2.getMfd()){
//                        return 1;
//                    }else if(p1.getMfd() < p2.getMfd()){
//                        return -1;
//                    }
//                return p1.getName().compareTo(p2.getName());
//            }        
//        });
//lambda 
//         TreeSet<Product> trSet = new TreeSet<>((cmp1,cmp2)->{             
//             int result = cmp1.getPrice() - cmp2.getPrice();                
//             if (result == 0){
//                 result = cmp1.getMfd()- cmp2.getMfd();                 
//             }
//             if (result == 0){
//                  result = cmp1.getName().compareTo(cmp2.getName());
//             }             
//             return result;             
//         } );
//Method Reference
        // TreeSet<Product> trSet = new TreeSet<>(Ch8_2_2::productCmpMethod);
       Comparator<Product> pComp= Comparator.
               comparing((prod)->prod.getPrice());
      pComp =  pComp.thenComparing(prod->prod.getMfd()).
               thenComparing(prod->prod.getName());
      //pComp = pComp.reversed();
     TreeSet<Product> trSet = new TreeSet<>(pComp);
        trSet.add(p1);
        trSet.add(p2);
        trSet.add(p3);
        trSet.add(p4);
        
        trSet.forEach(System.out::println);
        
        
        
    }
}
