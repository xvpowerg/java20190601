/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
public class Ch9_6 {

      static void showMyList( MyList<Test1> myList){
          myList.add(new Test1());
          myList.add(new Test2());
          Test1 t1 = myList.get(0);
      }
      //不可加數值
      static void showSubMyList(MyList<? extends Test1> myList){
        Test1 t1  = myList.get(0);
       // myList.add(new Test1());
       myList.foreach(System.out::println);        
      }
      //可加數值 但是只能是一樣的類型或子類型
      //可取值 但是類型為Object
      static void showSuperList(MyList<? super Test2> mysList){
          
          mysList.add(new Test2());
          mysList.add(new Test3());
          Test1 t2 =   (Test1)mysList.get(0);
          mysList.foreach((v)->System.out.println(v));          
      }
           
    public static void main(String[] args) {
      //MyList<Test1> myList = new MyList<Test2>();//錯誤
         MyList<Test1> myList =  new MyList<Test1>();
        showMyList(myList);
          showMyList(new MyList<>());
          
        MyList<Test3> list2=   new MyList<Test3>();
        list2.add(new Test3());
        list2.add(new Test3());
        showSubMyList(list2);  
        
         MyList<Test1> list3=   new MyList<Test1>();
         showSuperList(list3);
    }
    
}
