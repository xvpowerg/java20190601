/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
public class Ch9_5 {
    public static void main(String[] args) {
      MyList myList = new MyList();
        myList.add("Ken");
        myList.add("Vivin");
        myList.add("Lindy");
        myList.foreach(System.out::println);
        
        System.out.println(myList.get(1));
        
        MyList<Integer> myListInt = new MyList<>();
          myListInt.add(95);
          myListInt.add(73);
          myListInt.add(84);
          myListInt.add(25);
          myListInt.foreach(System.out::println);
    }
    
}
