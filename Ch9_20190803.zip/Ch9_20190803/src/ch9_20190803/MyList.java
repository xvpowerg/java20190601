/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;
import java.util.ArrayList;
import java.util.function.Consumer;

public class MyList<T> {
    private ArrayList<T> list = new ArrayList<>();
    public void add(T str){
        list.add(str);
    }
    
    public T get(int index){
        return list.get(index);
    }
    
    public int size(){
        return list.size();
    }
    
    public void foreach(Consumer<T> consumer){
        list.forEach(consumer);
    }
}
