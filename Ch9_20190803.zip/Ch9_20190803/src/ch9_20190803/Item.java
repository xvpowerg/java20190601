/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
//public class Item implements Comparable<Item>{
public class Item {
    private int id;
    private String name;

    public int compareTo(Item tmpItem){
        int result = id - tmpItem.id;
        if (result == 0){
            result = name.compareTo(tmpItem.getName());
        }
        return result;
    }
    
    public Item(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public String toString(){
        return id+":"+name;
    }
}
