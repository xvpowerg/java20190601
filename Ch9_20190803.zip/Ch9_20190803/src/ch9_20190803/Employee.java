/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
public class Employee{
    private String name;
    private int age;
    private int score;
  
    public Employee(String name, int age, int score) {
        this.name = name;
        this.age = age;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getScore() {
        return score;
    }
    
    public int hashCode(){
        return 31*score+age+name.hashCode();
    }
    public boolean equals(Object obj){
        if (obj != null && ! (obj instanceof Employee) ){
            return false;
        }
        Employee tmpObj = (Employee)obj;
        boolean result = 
                this.getAge() == tmpObj.getAge() &&
                this.getScore() == tmpObj.getScore()&&
                this.getName().equals(this.getName());
        return result;
    }
    public String toString(){
        return "name:"+this.getName()+
                " Age:"+this.getAge()+" Score:"+this.getScore();
    }
    
}
