/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.SortedMap;
public class Ch9_2 {

    public static void main(String[] args) {
            
    TreeMap<Integer,String> myTreeMap = new TreeMap<>();
        
       myTreeMap.put(25,"B");
       myTreeMap.put(15,"J");
       myTreeMap.put(7,"E");
       myTreeMap.put(6,"C");
       
      // myTreeMap.forEach((k,v)->System.out.println(k+":"+v));
        
       int ceilingKey = myTreeMap.ceilingKey(7);//>=7
       int higherKey = myTreeMap.higherKey(7);//>7
       
       int floorKey = myTreeMap.floorKey(15);//<=15
       int lowerKey = myTreeMap.lowerKey(15);//<15
       
       System.out.println(ceilingKey+":"+higherKey);
       System.out.println(floorKey+":"+lowerKey);
       
       ceilingKey = myTreeMap.ceilingKey(25);//>=25
       //higherKey = myTreeMap.higherKey(25);//>25
      //System.out.println(ceilingKey+":"+higherKey);
      
//      Entry<Integer,String> entry1 =  myTreeMap.ceilingEntry(15);
//      Entry<Integer,String> entry2 =  myTreeMap.higherEntry(15);
//       System.out.println(entry1.getKey()+":"+entry1.getValue());
//       System.out.println(entry2.getKey()+":"+entry2.getValue());
       
//     System.out.println(myTreeMap);
//    Entry<Integer,String>  entry3 =  myTreeMap.pollFirstEntry();
//    System.out.println(entry3.getKey()+":"+entry3.getValue());
//    System.out.println(myTreeMap);
    
     myTreeMap.replaceAll((k,v)->{return k+":"+v;});
    System.out.println(myTreeMap);
    
     SortedMap<Integer,String> subMap1 =  myTreeMap.subMap(7, 25);
     System.out.println(subMap1);
     subMap1.put(13, "X");//以目前案例而言subMap1.put 的key 不可以大於25 小於7
     System.out.println(myTreeMap);
    }
    
}
