/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

import java.util.ArrayList;
import java.util.Set;

/**
 *
 * @author howard
 */
public class Ch9_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      TestGeneric<ArrayList> tg1 = new  TestGeneric();
      
      TestGeneric2<String,ArrayList<String>> tg2 = new  TestGeneric2<>();
      ArrayList<String> names = new ArrayList<String>();
      tg2.testGeneric2("Vivin", names);
      tg2.testGeneric2("Ken", names);
      names.forEach(System.out::println);
    }
    
}
