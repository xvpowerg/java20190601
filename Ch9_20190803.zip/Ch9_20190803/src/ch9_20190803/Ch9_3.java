/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;
import java.util.TreeMap;
import java.util.Comparator;
import java.util.Scanner;
/**
 *
 * @author howard
 */
public class Ch9_3 {

    public static void main(String[] args) {
        
        
        
        Comparator<Item>  itemComp = (i1,i2)->{
        
               int result = i1.getId() - i2.getId();
               if (result == 0){
                   result = i1.getName().compareTo(i2.getName());
               }
               return result;
        };
        
        System.out.println("1 遞增排序");
        System.out.println("2 遞減排序");
        Scanner scan = new Scanner(System.in);
        int type = scan.nextInt();
        switch(type){
            case 1:
              break;
           case 2:
               itemComp = itemComp.reversed();
            break;  
           default:
             assert false : "錯誤的type"; 
        }
        
        TreeMap<Item,String> treeMap = new TreeMap<>(itemComp);
        
       Item i1 = new  Item(10,"Item1");
       Item i2 = new  Item(15,"Item2");
       Item i3 = new  Item(25,"Item3");
       Item i4 = new  Item(11,"Item4");
       Item i5 = new  Item(25,"Item5");
       
       treeMap.put(i1, "工廠1");
       treeMap.put(i2, "工廠2");
       treeMap.put(i3, "工廠3");
       treeMap.put(i4, "工廠4");
       
      treeMap.forEach((k,v)->{System.out.println(k+":"+v);}  );
        
    }
    
}
