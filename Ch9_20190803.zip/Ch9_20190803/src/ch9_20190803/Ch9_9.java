/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.function.Supplier;
import java.util.Random;
public class Ch9_9 {
    
    static String genString(){
        StringBuffer sb = new StringBuffer();
        Random ran = new Random();
        int count = ran.nextInt(16)+5;
        for (int i =1;i<=count;i++){
           //int charNumber = ran.nextInt(Character.MAX_VALUE)+1;
           int charNumber = ran.nextInt(26)+'a';
           sb.append((char)charNumber);
        }
        return sb.toString();
    }
    public static void main(String[] args) {
       
//      Stream stream = Stream.of("Ken","Vivin","Lindy");
//        stream.forEach(System.out::println);
    //System.out.println(genString());
        
//     Stream stStream =  Stream.generate(Ch9_9::genString).limit(10);
//      stStream.forEach(System.out::println);
      
      //Stream.iterate(1,(v)->v+1).limit(5).forEach(System.out::println);
       
      //IntStream.range(1, 20).forEach(System.out::println);
      //IntStream.rangeClosed(1, 20).forEach(System.out::println);
        
    }
    
}
