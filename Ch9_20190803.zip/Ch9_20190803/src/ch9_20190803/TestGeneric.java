         /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;
import java.util.List;
import java.util.function.Supplier;

public class TestGeneric<T> {
    public void testGeneric(T v){
        v.hashCode();
    }
    
    public <R> R test1(Supplier<R> supplier){        
        return supplier.get();        
    }
    
    public static <R> R test2(Supplier<R> supplier){
            return supplier.get();
    }
}


class TestGeneric2<T1,T extends List<T1>>{
      public void testGeneric2(T1 v,T list){
        list.add(v);
    }
    
    
}