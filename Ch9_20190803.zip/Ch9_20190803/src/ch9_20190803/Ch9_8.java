/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
public class Ch9_8 {

    public static void main(String[] args) {
        
      TestGeneric tg1 = new TestGeneric();
      Object obj = tg1.<Integer>test1(()->Integer.valueOf(20));
        Integer i = (Integer)obj;
                System.out.println(i);
                
     int v2 = TestGeneric.<Integer>test2(()->Integer.valueOf(50));
     System.out.println(v2);
     String v3 = TestGeneric.<String>test2(()->"Join");
      System.out.println(v3);
    }
    
}
