/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190803;

/**
 *
 * @author howard
 */
public class Ch9_4 {

    public static void main(String[] args) {
        int i =10;
        int k =2;
        try{
            assert k != 0 : "分母為零不正確";
            System.out.println(i / k);
        }catch(AssertionError error){
            System.out.println(error);
        }
        
        
      
        
        
        
        
    }
    
}
