package ch9_20190803;
import java.util.ArrayList;
import java.util.HashMap;
public class Ch9_1 {
    public static void main(String[] args) {
      /*              
       假設我有一群Employee
        請幫我用年齡分組
        Employee Ken 10
        Employee Iris 20
        Employee Vivin 10
        Employee Lindy 20
        
        map.get(10)->>Ken Vivin
        map.get(20)->>Iris Lindy        
        */
        
        Employee em1 = new Employee("Ken",10,50);
        Employee em2 = new Employee("Iris",20,60);
        Employee em3 = new Employee("Vivin",10,91);
        Employee em4 = new Employee("Lindy",20,75);
        
        ArrayList<Employee> list = new ArrayList<>();
        list.add(em1);
        list.add(em2);
        list.add(em3);
        list.add(em4);
        
        HashMap<Integer,String> userGroupMap = new HashMap();
        
        for (Employee emp : list){     
      
           userGroupMap.computeIfPresent(emp.getAge(), (k,v)->{                
               return v +" "+emp.getName();
           });
             userGroupMap.computeIfAbsent(emp.getAge(), (k)->emp.getName());
        } 
        
        
//        for (Employee emp : list){
//            int age = emp.getAge();
//            String valueName = emp.getName();
//            if (userGroupMap.containsKey(age)){
//                valueName =userGroupMap.get(age)+" "+valueName;
//            }
//            userGroupMap.put(age, valueName);
//        }
        userGroupMap.forEach((k,v)->{
                System.out.println(k+":"+v);        
        });
        
        
        
        
    }
    
}
