/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
public class Ch13_3 {
    
    
    
    public static void main(String[] args) throws Exception{
      //執行緒池
     ExecutorService es =  Executors.newCachedThreadPool();
        es.execute(()->{
        
            for (int i =1;i<=5;i++){
                System.out.println(i);
                try{
                    TimeUnit.SECONDS.sleep(1); 
                }catch(InterruptedException ex){
                    
                }
               
            }
        
        });
        
        for (int i=1;i<=10;i++){
                   es.execute(()->{
            System.out.println(Thread.currentThread().getName());
            try{
                 TimeUnit.SECONDS.sleep(ThreadLocalRandom.current().nextInt(3)+1); 
            }catch(InterruptedException ex){
                
            }
            });
        }
        TimeUnit.SECONDS.sleep(3); 
        
         for (int i=1;i<=10;i++){
                   es.execute(()->{
            System.out.println(Thread.currentThread().getName());
            try{
                 TimeUnit.SECONDS.sleep(ThreadLocalRandom.current().nextInt(3)+1); 
            }catch(InterruptedException ex){
                
            }
            });
        }
        es.shutdown();
        
        
        
        
    }
    
}
