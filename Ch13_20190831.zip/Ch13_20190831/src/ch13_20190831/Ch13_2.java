/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_2 {
    
        private  static class MyLock{
            int x = 10;
            
            public synchronized void test1(MyLock ml){
                System.out.println("計算中......");
                ml.test2();
            }
            public synchronized  void test2(){
                System.out.println(++x);
            }
            
        }
    
    
    
     public static void main(String[] args) {
         //死結
         // 一個以上的執行緒
        //資源互相等待的問題
         MyLock mylock1 = new MyLock();
           MyLock mylock2 = new MyLock();
        Thread th1 = new  Thread(()->{
        mylock1.test1(mylock2);
        
        });
        
        Thread th2 = new Thread(()->{
           mylock2.test1(mylock1);
        
        });
        th1.start();
        th2.start();
         
     }
}
