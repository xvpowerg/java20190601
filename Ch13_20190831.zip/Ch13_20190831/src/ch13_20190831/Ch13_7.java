/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;

import java.util.stream.LongStream;
import java.util.stream.Stream;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_7 {

    /**
     * @param args the command line arguments
     */
    
    static class Total{
        public long total = 1;
        public void mulitply(long n){
            System.out.println("n:"+n);
            System.out.println("total:"+total);
            total *= n;}
    }
    public static void main(String[] args) {
//        Total t1 = new Total();
//        LongStream.range(1, 10).parallel().forEach(t1::mulitply);
//        System.out.println(t1.total);

//    long total =  LongStream.
//            rangeClosed(1, 10).parallel().
//            reduce(1, (a,b)->a * b);
//    System.out.println(total);
//long sum =  LongStream.rangeClosed(1, 100).parallel().
//        reduce(0, (a,b)->{return a+b;});
//        System.out.println(sum);

//long sum =  LongStream.rangeClosed(1, 5).parallel().
//        reduce(0, (a,b)->{
//                System.out.println("a:"+a);
//             System.out.println("b:"+b);
//              System.out.println("========");
//            return a+b;}
//        
//        );
//        System.out.println(sum);

       int length =  Stream.of("AAA","BB","CC","D").parallel().
                reduce(0, (len,str)->{
                        System.out.println("len:"+len);
                        System.out.println("str:"+str);
                    return  str.length()+len;},
                        (len1,len2)->{
                             System.out.println("len1:"+len1);
                        System.out.println("len2:"+len2);
                            return len1 + len2;});
       
       System.out.println(length);
        
    }
    
}
