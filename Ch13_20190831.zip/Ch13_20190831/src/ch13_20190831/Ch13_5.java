/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Future;
public class Ch13_5 {

   
    public static void main(String[] args) throws Exception{
        ExecutorService es =   Executors.newFixedThreadPool(3);
        ExecutorService es2 = Executors.newCachedThreadPool();
        Future<Integer> fu =   es.submit(()->{
            System.out.println("開始產生數字....");
            try{
                TimeUnit.SECONDS.sleep(3);
            }catch(InterruptedException ex){
                System.out.println(ex);
            }
            return ThreadLocalRandom.current().nextInt(5);
        
        });
        
        System.out.println("Main1....");
        
        es2.execute(()->{
            try{
                  System.out.println(fu.get());
            }catch(InterruptedException | ExecutionException  ex){
                System.out.println(ex);
            }
           
        });
        
       
        
        System.out.println("Main2....");
        es2.shutdown();
        es.shutdown();
        
    }
    
}
