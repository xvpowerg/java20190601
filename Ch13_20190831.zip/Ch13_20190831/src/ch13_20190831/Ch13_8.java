/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;
public class Ch13_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/MyUserDB";
        String user = "qwer";
        String password = "12345";
        Connection conn = null;
         Statement stm = null;
         int id = new Random().nextInt(Integer.MAX_VALUE);
         Scanner scan = new Scanner(System.in);
         System.out.println("請輸入姓名");
        String name = scan.next();
           System.out.println("請輸入身高");
         String height = scan.next();
        try{
             conn = DriverManager.getConnection(url, user, password);
              stm = conn.createStatement();
              String sql = String.format("INSERT INTO MYUSER(ID,USER_NAME,HEIGHT) VALUES(%d,'%s',%s)", id,name,height);
              System.out.println(sql);
             int count = stm.executeUpdate(sql);
             if (count > 0){
                 System.out.println("新增成功");
             }else{
                 System.out.println("新增失敗");
             }
        }catch(SQLException ex){
            System.out.println(ex);
        }finally{
            try{
                   conn.close();
                    stm.close();
            }catch(Exception ex){
                
            }
       
        }
       
        
        
        
    }
    
}
