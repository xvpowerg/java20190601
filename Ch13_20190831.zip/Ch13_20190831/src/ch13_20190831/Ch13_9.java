/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
public class Ch13_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String url = "jdbc:derby://localhost:1527/MyUserDB";
        String user = "qwer";
        String password = "12345";
        try(Connection conn = DriverManager.getConnection(url,user,password);
             Statement stm =    conn.createStatement();){
           ResultSet reset =  stm.executeQuery("SELECT * FROM MYUSER");
           ResultSetMetaData  metaData = reset.getMetaData();
           System.out.println(metaData.getColumnName(2));
           
            while(reset.next()){
//                System.out.print("ID:"+reset.getInt(1));
//                 System.out.print("Name:"+reset.getString(2));
//                 System.out.print("Height"+reset.getFloat(3));
                    System.out.print("ID:"+reset.getInt("ID"));
                 System.out.print("Name:"+reset.getString("USER_NAME"));
                 System.out.print("Height"+reset.getFloat("HEIGHT"));
                 System.out.println();
            }
        }catch(SQLException ex){
            System.out.println(ex);
        }
    }
    
}
