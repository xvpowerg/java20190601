/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_1 {
        private int x;
//           private  void testThread(){
//             System.out.println("Out 1:"+Thread.currentThread().getName());
//            for (int i =1;i<=5;i++){
//                 System.out.println(Thread.currentThread().getName());
//                x++;
//                System.out.println(x);
//            }
//           System.out.println("Out 2:"+Thread.currentThread().getName());  
//        }
   
           
           
//        private synchronized void testThread(){
//             System.out.println("Out 1:"+Thread.currentThread().getName());
//            for (int i =1;i<=5;i++){
//                 System.out.println(Thread.currentThread().getName());
//                x++;
//                System.out.println(x);
//            }
//           System.out.println("Out 2:"+Thread.currentThread().getName());  
//        }
        
        
                
        private  void testThread(){
             System.out.println("Out 1:"+Thread.currentThread().getName());
             synchronized(this){
                 for (int i =1;i<=5;i++){
                 System.out.println(Thread.currentThread().getName());
                        x++;
                        System.out.println(x);
                    }
             }
            
           System.out.println("Out 2:"+Thread.currentThread().getName());  
        }
        
    public static void main(String[] args) {
        
        Ch13_1 c131 = new Ch13_1();
        Thread t1 = new Thread(()->{
         c131.testThread();
        },"Th1");
          Thread t2 = new Thread(()->{
            c131.testThread();
        },"Th2");
       t1.start();
       t2.start();
     
    }
    
}
