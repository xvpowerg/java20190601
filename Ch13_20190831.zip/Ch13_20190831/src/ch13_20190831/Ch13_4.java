/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
public class Ch13_4 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
       ExecutorService es =  Executors.newFixedThreadPool(3);
       
       for (int i=1;i<=5;i++){
            String msg = i+"";
                 es.execute(()->{
                     
            System.out.println(msg+"Thread Name:"+Thread.currentThread().getName());
                 try{
                     TimeUnit.SECONDS.sleep(2); 
                 }catch(InterruptedException ex){
                     System.out.println(ex);
                 }

            });
       }
    //es.shutdown();
     List<Runnable> list = es.shutdownNow();
       list.forEach(run->{
           System.out.print("shutdownNow:");
           run.run();});
       
    }
    
}
