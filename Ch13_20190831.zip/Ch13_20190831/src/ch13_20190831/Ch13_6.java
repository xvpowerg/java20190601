/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190831;

import java.util.ArrayList;
public class Ch13_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
         list.add(7);
         list.add(5);
          list.add(8);
            list.add(31);
//        list.stream().forEach((v)->{
//            System.out.println("v:"+v);
//           System.out.println("Name:"+Thread.currentThread().getName());
//        });
         list.parallelStream().forEach((v)->{
            System.out.println("v:"+v);
           System.out.println("Name:"+Thread.currentThread().getName());
        });
            
    }
    
}
