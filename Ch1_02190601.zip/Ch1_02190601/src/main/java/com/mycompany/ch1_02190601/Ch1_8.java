/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

public class Ch1_8 {
    public static void main(String[] args) {
            int v1 = 11;//01011
            int v2 = 23;//10111
            
            System.out.println(v1 & v2);
            System.out.println(v1 | v2);
            System.out.println(v1 ^ v2);//11100
        
            int v3 = 5;
            //<<表示v3 * 2的n次方 以下案例是v3乘上2的3次方
            System.out.println(v3 << 3);
               //>>表示v4 / 2的n次方 以下案例是v4除上2的2次方
            int v4 = 16;
            System.out.println(v4 >>2);
            
        
        
    }
    
}
