/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_10 {
    public static void main(String[] args){
        //switch case
        //()可傳入的類型有 byte short int char enum String
        int action  =2;
        switch(action){
            case 1:
                System.out.println("走");
                break;
            case 2:
                System.out.println("跑");
                break;
        }
        
    }
}
