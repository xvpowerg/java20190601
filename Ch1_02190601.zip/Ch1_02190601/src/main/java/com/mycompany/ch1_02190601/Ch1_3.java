/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_3 {
    public static void main(String[] args){
        int a1 = 9;
        int a2 = 2;
        //%d 我要印出的格式是整數
        //%f 我要印出的格式是浮點數
        //%s 我要印出的格式是字串
        //%n 表示我要印出的是段行
        System.out.printf("%d + %d = %d %n",a1,a2,a1+a2);
        System.out.printf("%d - %d = %d %n",a1,a2,a1- a2);
        System.out.printf("%d * %d = %d %n",a1,a2,a1 * a2);
        //java的除法其實在求商數
        System.out.printf("%d / %d = %d %n",a1,a2,a1 / a2);
        //必須把其中一個數字轉成浮點數類型
        //如果計算式當中有浮點數,結果就會是浮點數類型
        float f2 = 2.0f;
        //.2f取道小數點第二位並且四捨五入
        System.out.printf("%d / %.2f = %.2f %n",a1,f2,a1 / f2);
        //做餘數
        System.out.printf("%d %% %d = %d %n",a1,a2,a1 % a2);
        //()
        //- + ++ --
        //* / %
        //+ - 
        //> < >= <= == !=
        //& |
        //&&
        //||
        //?:
        //+= -= *=
        //=
      
        
        
    }
}

