/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_2 {
    public static void main(String[] args){
        //變數名稱 開頭只能英文字母 $ 或 _
        //變數第二單字開始 可以是英文字母 $ 或 _ 或數字
        
       //二進位
        int price= 0b1010;
        System.out.println(price);
       //8進位
         int oct= 0017;
         System.out.println(oct);
       //16進位
       //A=10 B=11 C=12 D=13 E=14 F=15
         int hex = 0x00A2;
      System.out.println(hex);
      //所以_並不會改變數字本身
      //底的線的口訣:底線前後必須是底線或數字
      int money = 1_000_000____000;
      float af = 3.14_1_5f;
      int hex2 = 0xFA01F__F;
      int binary = 0b10_110;
      int oct2 = 0__75_21;
      
    }
}
