/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_6 {
    public static void main(String[] args){
        int a1 = 20;
        int a2 = 20;
        System.out.println(a1 > a2);
        System.out.println(a1 < a2);
        System.out.println(a1 >= a2);
        System.out.println(a1 <= a2);
        System.out.println(a1 != a2);
        System.out.println(a1 == a2);
        System.out.println("=======================");
        
        String name1 = "Ken";
        String name2 = "Ken";
        String name3 = new String("Ken");
        System.out.println(name1+":"+name2);
        System.out.println(name1+":"+name3);
        System.out.println(name1 == name2);
        System.out.println(name1 == name3);
        //比較非基本型態 請使用equals
        System.out.println(name1.equals(name3));
        
        
        
    }
}

