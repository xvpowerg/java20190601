/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_1 {
    public static void main(String[] args){
        //System.out.println("Hello!");        
        //初階1z0-808 進階:1z0-809
        //整數
          //byte 8bit  -128~127
          //short 16bit -32768~32767
          //int 32bit -2147483648~2147483647 default
          //long 64bit
        //浮點數 不適哪麼準確 會有誤差
           //float 32bit
           //double 64bit default
        //文字
             // char 16bit  0~65535 沒有負數
             //String 可變化 不算基本型態             
        //布林
            //boolean 可能是 1 bit
        
        byte b1 = 15; 
        System.out.println(b1);        
        int v2 = 256142;
       System.out.println(v2);     
       //加上f改變為float類型
       float f1 = 3.1415f;
       System.out.println(f1); 
       //把預設為int的類型轉成long
       long myLong = 2147483648L;
       System.out.println(myLong);
       //字元 Unicode 16bit
       //數字 < 大寫字母 < 小寫字母 < 中文
       //java預設排序 小到大排序 遞增排序 ASC
       char c1 = 'B';
       System.out.println(c1);
       char c2 = 65;
       System.out.println(c2);      
       char c3 = '\u0043';
        System.out.println(c3);
       
        int number1 = '5';
        System.out.println(number1);
       int number2 = 'a';
       System.out.println(number2);
       int number3 = '哈';
       System.out.println(number3);
       
       String s1 = "Zabc1";
       String s2 = "abc"; //s2大於s1
       
       String s3 = "aaaa";//字元一樣比長度 s3大於s4
       String s4 = "aa";
       
       //不可用0或1
       boolean bool = false;
       
       
       
    }
}
