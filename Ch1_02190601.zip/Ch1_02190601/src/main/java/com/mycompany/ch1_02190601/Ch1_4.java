/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_4 {
    public static void main(String[] args){
        //累加運算
        int coin = 0;
        //coin = coin +1;
        //coin = coin +2;
        coin += 1;
        coin += 2;
        System.out.println(coin);
        
        float point = 1.5f;
       // coin = coin + point;
       coin += point;
       System.out.println(coin);
        
    }
}
