/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_5 {
    public static void main(String[] args){
        int count = 0;
        count++;
        ++count;
        System.out.println(count);
        --count;
         System.out.println(count);
       System.out.println("================");     
       int index = 0;
       //++在前 是先把index 數值+1 在顯示
        //System.out.println(++index); 
        index = index +1;
        System.out.println(index); 
        //++在後 先顯示index 在+1
       // System.out.println(index++); 
        System.out.println(index); 
        index = index +1;
        
        System.out.println(index); 
     System.out.println("================");     

     int value = 2;
     int x = ++value;
//     value = value +1;
//     int x = value;     
     int y = value++;
//     int y = value;
//     value = value +1;
     System.out.println(x);//3
     System.out.println(y);//3
     System.out.println(value);//4
   
     System.out.println("================");     
       int i = 2;       
       int h = 3 + i++ + ++i -2 +i++;
       System.out.println(h);
       System.out.println(i);
       
     
     
    }
}
