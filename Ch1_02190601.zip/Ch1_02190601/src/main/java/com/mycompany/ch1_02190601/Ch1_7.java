/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;

/**
 *
 * @author howard
 */
public class Ch1_7 {
    public static void main(String[] args){
        //且 &  &&  兩邊為真才為真
        //或 |  || 單邊為真就是真
        //反向 ! 唱反調
        //互斥 ^ 一真一假才是真
        //
        boolean b1 = true;
        boolean b2 = false;
        //&& || 短路現象
        System.out.println(b1 && b2);
        System.out.println(b1 || b2);
        System.out.println(!b1);
        System.out.println(b1 ^ b2);
        System.out.println("==================");
        //&& 短路(Short circuit)現象  左邊是false右邊就不執行
        int i = 2;
        boolean b3 = ++i > 2 && i++ <5;
        System.out.println(b3);
        System.out.println(i);
        int k = 2;
        boolean b4 = ++k < 2 && k++ <5;   
        System.out.println(b4);
        System.out.println(k);
        //|| 短路(Short circuit)現象 左邊是true右邊就不執行
         System.out.println("===================");
        int m = 3;
        boolean b5 = ++m < 2 || ++m > 1;
        System.out.println(b5);
        System.out.println(m);
        int n = 3;
        boolean b6 = ++n > 2 || ++n > 1;
        System.out.println(b6);
        System.out.println(n);
    }
}
