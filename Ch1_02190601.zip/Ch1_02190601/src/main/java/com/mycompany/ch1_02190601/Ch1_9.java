/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch1_02190601;
import java.util.Scanner;
public class Ch1_9 {
    public static void main(String[] args){
       /* System.out.println("請輸入年齡");
        Scanner scan = new Scanner(System.in);
        int age = scan.nextInt();
        System.out.println("您輸入的年齡:"+age);
        if (age >=18)
            System.out.println("成年");         
        else
            System.out.println("未成年");       
        System.out.println("未滿18");*/
       
         Scanner scan = new Scanner(System.in);
        System.out.println("請輸入pm25");
        int pm25 = scan.nextInt();
        
        if (pm25 >=0 &&  pm25 <= 50)
            System.out.println("良好");
        else if(pm25 >= 51 && pm25 <= 100)
            System.out.println("普通");
        else if(pm25 >=101 && pm25 <=150)
            System.out.println("不健康");
        else
            System.out.println("非常不健康");
    }
}
