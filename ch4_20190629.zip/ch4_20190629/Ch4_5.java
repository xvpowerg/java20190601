/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;
//這個類在此java常使用才需import
/**
 *
 * @author howard
 */
public class Ch4_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Report repor = new Report();
        repor.testRepport();
        //full name
        com.mycompany.ch4_20190629.test.Report r2 = 
                new com.mycompany.ch4_20190629.test.Report();
        r2.printReport();
    }
    
}
