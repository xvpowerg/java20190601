/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */

//extends 會將父類別的 部分方法繼承過來
//部分方法要看讀取權限
//如果public或protected的方法或屬性一定會繼承
//如果 default的方法或屬性(沒有加上讀取權限的方法)在相同package才會繼承
//建構子不會被繼承
public class PrimarySchool extends Student {
    //所有的建構子內，如果沒自行呼叫this()或是super()的話，預設情況會呼叫父類別預設建構子
    //預設建構子就是沒有參數的建構子
    PrimarySchool(){
      
    }
     PrimarySchool(String name,int score,float height){
         //super()呼叫父類建構子
         //必在建構子類呼叫，而且必須是第一行命令
         //this()與super()不可能同時出現
       super(name,score,height);
    }
     //複寫 Override
     public void print(){
         System.out.print("小學:");
         //super. 可呼叫父類別的方法
         super.print();
     }
}
