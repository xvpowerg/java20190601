/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;
import com.mycompany.ch4_20190629.test.TestModifier2;
/**
 *
 * @author howard
 */
public class Ch4_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        TestModifier1 tm1 = new TestModifier1();
        System.out.println(tm1.testPuble);
        tm1.testProtected = "input new value";
        System.out.println(tm1.testProtected);
        System.out.println(tm1.testDefault);    
        //使用其他package的類別必須import
        TestModifier2 tm2 = new TestModifier2();        
        System.out.println(tm2.testPuble);
    }
    
}
