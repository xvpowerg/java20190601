/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;
import java.io.IOException;
/**
 *
 * @author howard
 */
public class Ch4_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException {
        // TODO code application logic here
         TestException tex = new TestException();
          System.out.println("Setp 1");
        tex.testException1();
         System.out.println("Setp 2");
        
    }
    
}
