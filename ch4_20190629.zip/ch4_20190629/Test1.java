/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class Test1 {
    public Test1(){
         System.out.printf("Test1()%n");   
    }
    public Test1(int v1,String s2){
        this();
       System.out.printf("Test1 "
          + "int:%d String:%s%n",v1,s2);  
    }
    
    public Test1(float f2,String s2){      
        System.out.printf("Test1 "
       + "float:%f String:%s%n",f2,s2); 
    }
    
}
