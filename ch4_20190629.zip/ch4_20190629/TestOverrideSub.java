/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class TestOverrideSub extends TestOverride{
    @Override
    //public
    public void testPublic(){
        System.out.println("Test2 Public");
    }
    @Override
    //protected public
     protected void testProtected(){
        System.out.println("Test2 Protected");
    }
     @Override
     //default protected public
    void testDefault(){
        System.out.println("Test2 Default");
    }
    
    //就算不是Override不會出錯
    //如果要檢查是否為正確的Override可使用@Override
   // @Override
    private void testPrivate(){
        System.out.println("Test1 Private");
    }
    
    //複寫不可修改
   public int testReturnInt(){
        return 10;
    }
   //return 可子類或一樣
    public Test2 testReturnBject(){
        return new Test2(1,"");
    }
    
     
}
