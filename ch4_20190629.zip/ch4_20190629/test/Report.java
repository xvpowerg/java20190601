/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629.test;

/**
 *
 * @author howard
 */
public class Report {
    public void printReport(){
        System.out.println("print Report");
    }
}
