/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629.test;


public class TestModifier2 {
    public String testPuble = "test2 public";
    protected String testProtected = "test2 protected";
    String testDefault = "test2 Default";
    private String testPrivae = "test2 private";
}
