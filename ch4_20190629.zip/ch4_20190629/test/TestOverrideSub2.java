/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629.test;
import com.mycompany.ch4_20190629.TestOverride;
/**
 *
 * @author howard
 */
public class TestOverrideSub2 extends TestOverride {
   @Override
    public void testPublic(){
        System.out.println("Test1 Public");
    }
    @Override
    protected void testProtected(){
        System.out.println("Test1 Protected");
    }
    //@Override
    void testDefault(){
        System.out.println("Test1 Default");
    }
   // @Override
    private void testPrivate(){
        System.out.println("Test1 Private");
    }
}
