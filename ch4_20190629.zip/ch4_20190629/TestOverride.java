/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class TestOverride {
    /*  Overrider
        複寫規則
     1 讀取權限只能越來越開放不能封閉
       如果我的讀取權限是:public 只能用public複寫
       如果我的讀取權限是:protected 能用protected public複寫
       如果我的讀取權限是:default 
             在相同package能用default protected public複寫
             不在相同package不能複寫
       如果我的讀取權限是:private 不能複寫
    2 回傳值
       如果是基本型態必須一模一樣
        如果是非基本型態一樣或子類型
    3 方法名稱與參數類型必須樣
    4 例外可選拋出一樣或子類或不拋出
    */
    public void testPublic(){
        System.out.println("Test1 Public");
    }
    protected void testProtected(){
        System.out.println("Test1 Protected");
    }
    void testDefault(){
        System.out.println("Test1 Default");
    }
    private void testPrivate(){
        System.out.println("Test1 Private");
    }
    
    public int testReturnInt(){
        return 10;
    }

   public Test2 testReturnBject(){
        return new Test2(1,"");
    }
    
}
