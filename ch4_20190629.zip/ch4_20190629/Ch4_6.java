/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;
import java.io.IOException;
/**
 *
 * @author howard
 */
public class Ch4_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Student st1 = new Student();
//        st1.setName("Vivin");
//        st1.setHeight(170.5f);
//        st1.setScore(-10);//0~100
//        st1.print();

        //例外分2大類
        //1 直接繼承Exception為必要例外檢測 checked exceptions
          //一定要使用try catch 或 拋出例外
          TestException tex = new TestException();
          //try嘗試擷取錯誤
          //catch 把對應的錯誤放到變數內
          System.out.println("Setp 1");
          try{
          System.out.println("Setp 2");    
              tex.testException1();
         System.out.println("Setp 3");    
          }catch(IOException ex){
              System.out.println(ex);
          }
        System.out.println("Setp 4");      
          
        //2 直接繼承RuntimeException為非必要例外檢測 unchecked exceptions
          //不一定要 使用try catch 或 拋出例外 
          
           
    }
    
}
