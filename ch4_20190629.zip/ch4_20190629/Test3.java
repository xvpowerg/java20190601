/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class Test3 extends Test2 {
     public Test3(int v1,float f1,String s2){
         super(73,f1,s2);
         System.out.printf("Test3 int:%d "
           + "float:%f String:%s%n",v1,f1,s2);
    }
    
    public Test3(float f2,String s2){
        this(15,f2,s2);
        System.out.printf("Test3 "
         + "float:%f String:%s%n",f2,s2);
    }
}
