/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class Test2 extends Test1 {
    public Test2(int v1,float f1,String s2){
        //做做看加上super(f1,s2); 之後的答案
        super(f1,s2); 
          System.out.printf("Test2 "
                  + "int:%dfloat:%f String:%s%n",v1,f1,s2);  
    }
    
    public Test2(float f2,String s2){
        super(f2,s2); 
        System.out.printf("Test2 "
                + " float:%f String:%s%n",f2,s2);
         
    }
}
