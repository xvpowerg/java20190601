/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;
import com.mycompany.ch4_20190629.test.TestModifier2;
/**
 *
 * @author howard
 */
public class TestModifier3 extends TestModifier2{
    public void test1(){
        System.out.println(this.testProtected);
        System.out.println(this.testPuble);               
    }
}
