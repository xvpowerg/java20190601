/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class Ch4_3 {
    
     static void printStudent(Student st){
        st.print();
    }
    public static void main(String[] args) {
       //多型（Polymorphism）
        Student st1 = new PrimarySchool("Join",10,155.2f);
        Student st2 = new HighSchool("Vivin",97,162.2f);
        //st1.print();
        printStudent(st1);
        printStudent(st2);
    }
    
}
