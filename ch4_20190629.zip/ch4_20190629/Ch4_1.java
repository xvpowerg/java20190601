/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class Ch4_1 {
    public static void main(String[] args) {
      
        Student st1 = new Student("Ken",95,175.6f);
        st1.setHeight(185.5f);
        st1.print();
        
        PrimarySchool ps = new PrimarySchool("Vivin",79,155.6f);
        ps.print();
    }
    
}
