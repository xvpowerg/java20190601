/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

public class Student {
    private String name;
    private int score;
    private float height;
    
      
    public void print(){
     System.out.println(getName()+":"+
             getScore()+":"+getHeight());
    }
    
   Student(){
       
   }
    //JavaBean
    //POJO  Plain Ordinary Java Objec
    Student(String name,int score,float height){
        this.name = name;
        this.score = score;
        this.height = height;        
    }    
    public void setName(String name){
        //this. 表示目前物件
        //this 必須用在非靜態
        this.name = name;
    }
    public String getName(){
        return this.name;
    }    
    public void setScore(int score){
        if (score <0 || score >100){
            //System.out.println("錯誤的成績!");
            //拋出例外
           throw new IllegalArgumentException("錯誤的成績!");
           
        }
        
        this.score = score;
    }
    public int getScore(){
        return this.score;
    }
    public void setHeight(float height){
        this.height = height;
    }
    public float getHeight(){       
        return height;
    }
    
  
}
