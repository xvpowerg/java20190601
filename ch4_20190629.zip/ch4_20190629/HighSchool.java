/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ch4_20190629;

/**
 *
 * @author howard
 */
public class HighSchool extends Student{
    
     HighSchool(){
        
    }
    
     HighSchool(String name,int score,float height){
        super(name,score,height);
    }
     
    public void print(){
        System.out.print("高中");
        super.print();
    } 
     
}
