/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Ch12_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
         File f = new File("/Users/shihhaochiu/javadir/st.dao");
         try(FileInputStream fins = new FileInputStream(f);
            ObjectInputStream oIng = new ObjectInputStream(fins);){
             Student st = (Student)oIng.readObject();
             System.out.println(st);
              System.out.println(st.getBook1());
               System.out.println(st.getMacAddress());
         }
    }
    
}
