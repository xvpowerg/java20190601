/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Ch12_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Path p1 =  Paths.get("/Users/shihhaochiu/javadir/myFile.txt");
      Path root =  p1.getRoot();
      System.out.println(root);
      int nameCount = p1.getNameCount();
       System.out.println(nameCount);
      Path namePath = p1.getName(2);
      System.out.println(namePath);       
      
      Path subPath  = p1.subpath(0, 3);
        System.out.println(subPath);
      
        Path p2 = Paths.get("./../test1");
       Path newP2 =  p2.normalize();
       System.out.println(newP2);
        System.out.println(p2.isAbsolute());
        System.out.println(p2.toAbsolutePath());
        
        //
         Path p3 = Paths.get("/Users/shihhaochiu/javadir");
         Path p4 = Paths.get("myFile.txt");
         Path p5 =  p3.resolve(p4);
         System.out.println(p5);
        
         Path p6 = Paths.get("/Users/shihhaochiu/javadir");
         Path p7 = Paths.get("/myFile/name.txt");
         Path p8 =  p6.resolve(p7);
         System.out.println(p8);
         
    }
    
}
