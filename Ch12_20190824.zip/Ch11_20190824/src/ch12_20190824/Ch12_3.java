/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;

/**
 *
 * @author shihhaochiu
 */
public class Ch12_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Student st1 = new Student("Howard",31,172);
       st1.setClassId("A0001");
       st1.appendSocre(85);
       st1.appendSocre(76);
       st1.appendSocre(98);
       System.out.println(st1);//希望輸出 name age height classId score:85,76,98
    }
    
}
