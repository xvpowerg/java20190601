/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
public class Ch12_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File file = new File("/Users/shihhaochiu/javadir/nameList.dao");
        try(FileInputStream fin = new FileInputStream(file);
                ObjectInputStream objIn = new ObjectInputStream(fin)){
            
           ArrayList<String> list = (ArrayList) objIn.readObject();
           
            list.forEach(System.out::println);
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex);
        }
        
        
        
    }
    
}
