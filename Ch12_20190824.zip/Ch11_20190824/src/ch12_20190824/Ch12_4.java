/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
public class Ch12_4 {

    
    public static void main(String[] args)throws Exception {
       File f = new File("/Users/shihhaochiu/javadir/st.dao");
     Student st1 = new Student("Howard",31,172);
       st1.setClassId("A0001");
       st1.appendSocre(85);
       st1.appendSocre(76);
       st1.appendSocre(98);
       st1.addBook1(new Book("快快樂樂學Java","ISBN0001"));
       st1.setMacAddress("198.198.127.61");
       try(FileOutputStream fou = new FileOutputStream(f);
          ObjectOutputStream objStr = new  ObjectOutputStream(fou) ){
           objStr.writeObject(st1);
       }
    }
    
}
