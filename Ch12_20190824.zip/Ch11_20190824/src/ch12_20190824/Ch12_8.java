/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
/**
 *
 * @author shihhaochiu
 */
public class Ch12_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//          Path p9 = Paths.get("/Users/shihhaochiu/javadir/myFile.txt");
//          try{
//            List<String> list =    Files.readAllLines(p9);
//          list.stream().forEach(System.out::println);
//          }catch(IOException ex){
//              System.out.println(ex);
//          }
            
        Path p1 = Paths.get("/Users/shihhaochiu/javadir/");
        try{
             Stream<Path> allPath =   Files.walk(p1);
         List<String>  pathList =   allPath.map(path->path.toString()).collect(Collectors.toList());
          Path p10 = Paths.get("/Users/shihhaochiu/javadir/myFile2.txt");
          Files.write(p10, pathList);
        }catch(IOException ex){
            System.out.println(ex);
        }
         
         
           
            //Files.write(p10, lines, options)
          
    }
    
}
