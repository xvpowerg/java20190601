/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;

/**
 *
 * @author shihhaochiu
 */
public class Person implements java.io.Serializable {
     private String name;
     private int age;
     private float height;
     public Person(){
         
     }
    public Person(String name, int age,float height) {
        this.name = name;
        this.age = age;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }
    
    public String toString(){
        return name+":"+age+":"+height;
    }
    
    
}
