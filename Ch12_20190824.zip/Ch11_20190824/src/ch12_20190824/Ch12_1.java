/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
public class Ch12_1 {

   
    public static void main(String[] args) {
       ArrayList<String> list = new ArrayList<>();
        for (int i =1;i<=1000;i++){
            list.add("Test"+i);
        }
        File file = new File("/Users/shihhaochiu/javadir/nameList.dao");
        try(FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oou = new ObjectOutputStream(fout)){
            oou.writeObject(list);
        }catch(IOException ex){
            System.out.println(ex);
        }
        
        
    }
    
}
