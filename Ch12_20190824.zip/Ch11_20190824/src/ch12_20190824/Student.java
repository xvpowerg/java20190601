/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.io.IOException;

/**
 *
 * @author shihhaochiu
 */
public class Student extends Person implements java.io.Serializable{
    private static final long serialVersionUID=0x71977b0cc627L;
    private String classId;
    private List<Integer>  scores = new ArrayList();
    //transient 忽略
     private  Book[] books = new Book[5];
     
     
     private transient  String macAddress;
    
    //private transient Book[] books = new Book[5];
    public String  getMacAddress(){
        return macAddress;
    }
    
      public void  setMacAddress(String macAddress){
        this.macAddress = macAddress;
    }
            
    public Student(String name,int age,float height){
        super(name,age,height);
    }
    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public List<Integer> getScore() {
        return scores;
    }

//    public void setScore(List<Integer> score) {
//        this.score = score;
//    }
    public void appendSocre(int socre){
        this.scores.add(socre);
    }
     public void addBook1(Book b1){
        books[0] = b1;
    }
     public Book getBook1(){
        return books[0];
    }
    public String toString(){
        String scoreStr = this.scores.stream().map((sc)->sc+"").collect(Collectors.joining(","));
       return super.toString()+":"+classId+":"+scoreStr;
    }
    //序列化時呼叫
    private void writeObject(java.io.ObjectOutputStream out)throws IOException{
        
         System.out.println("Student writeObject");
         out.defaultWriteObject();
    }
    
    //反序列化
    private void readObject(java.io.ObjectInputStream in)throws IOException,ClassNotFoundException{
         System.out.println("Student readObject");
         in.defaultReadObject();
         this.setMacAddress("127.0.0.1");
        
    }
    
}
