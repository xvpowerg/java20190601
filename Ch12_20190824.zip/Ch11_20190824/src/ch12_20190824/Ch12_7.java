/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190824;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.PathMatcher;
import java.util.stream.Stream;
public class Ch12_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//       Path p1 =  Paths.get("/Users/shihhaochiu/javadir/sfMyFile2.txt");
//       boolean isDirectory =  Files.isDirectory(p1);
//      boolean isSymbolicLink =  Files.isSymbolicLink(p1);
//      System.out.println(isDirectory);
//       System.out.println(isSymbolicLink);
//       
//       Path p2 = Paths.get("/Users/shihhaochiu/javadir/./aaaa.txt");
//         Path p3 = Paths.get("/Users/shihhaochiu/javadir/aaaa.txt");
//         try{
//          boolean isSameFile =  Files.isSameFile(p2, p3); 
//          System.out.println(isSameFile);
//         }catch(IOException ex){
//             System.out.println(ex);
//           }
         
         
//        Path p4 = Paths.get("/Users/shihhaochiu/javadir/myDir");
//        try{
//           Files.createDirectory(p4); 
//        }catch(IOException ex){
//            System.out.print(ex);
//        }
         
              
//        Path p5 = Paths.get("/Users/shihhaochiu/javadir/myDir2/myDir2_1");
//        try{
//           Files.createDirectories(p5); 
//        }catch(IOException ex){
//            System.out.print(ex);
//        }
         
//    Path p5 = Paths.get("/Users/shihhaochiu/javadir/myFile.txt");
//    Path p6 = Paths.get("/Users/shihhaochiu/javadir/myFile_copy.txt");
//    try{
//          //Files.copy(p5, p6,StandardCopyOption.REPLACE_EXISTING);
//          Files.copy(p5, p6,StandardCopyOption.ATOMIC_MOVE);
//    }catch(IOException ex){
//        System.out.println(ex);
//    }

//     Path p7 = Paths.get("/Users/shihhaochiu/javadir/myFile.txt");
//     Path p8 = Paths.get("/Users/shihhaochiu/javadir/myDir2/myFileMove.txt");
//     try{
//         Files.move(p7, p8,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);
//     }catch(IOException ex){
//         System.out.println(ex);
//     }
      Path p9 = Paths.get("/Users/shihhaochiu/javadir/");
//      try{
//       Stream<Path> str =  Files.list(p9);   
//       str.forEach(path->System.out.println(path));
//      }catch(IOException ex){
//          System.out.println(ex);
//      }
     
          FileSystem fs = FileSystems.getDefault();
         PathMatcher pm =  fs.getPathMatcher("glob:**/*.txt");
         PathMatcher pm2 =  fs.getPathMatcher("glob:**/???.txt");
          PathMatcher pm3 =  fs.getPathMatcher("glob:**/[a-z][a-z][a-z].txt");
            PathMatcher pm4 =  fs.getPathMatcher("glob:**/[1-9][1-9][1-9].txt");
     try{
       Stream<Path> str =  Files.list(p9);   
//       str.filter(ph1->pm.matches(ph1)).forEach(System.out::println);
// str.filter(ph1->pm2.matches(ph1)).forEach(System.out::println);
//str.filter(ph1->pm3.matches(ph1)).forEach(System.out::println);
//str.filter(ph1->pm4.matches(ph1)).forEach(System.out::println);

      }catch(IOException ex){
          System.out.println(ex);
      }
     
     
          try{
       Stream<Path> str2 =  Files.walk(p9,2);   
       str2.forEach(System.out::println);
      }catch(IOException ex){
          System.out.println(ex);
      }
     
    }
    
}
