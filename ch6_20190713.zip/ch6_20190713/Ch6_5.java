/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
 class Ch6_5 {
    private int value3;
    private String id;
    Ch6_5(int value3,String id){
        this.value3 = value3;
        this.id = id;
    }
        // 內部類分3種
    //1 靜態 2 非靜態的 3 匿名  
    //非靜態的 內部類可以讀取外部類的所有屬性與方法
    class NoneStatic{
        private int value1;
        private String value2;
        private String id;
        public NoneStatic(){
        }
        public NoneStatic(int value1,String value2){
            this.value1 = value1;
            this.value2 = value2; 
            //是測試內部類屬性名稱跟外部類一樣時的用法
            id ="id:"+ Ch6_5.this.id;
        }     
        public int getValue1(){
            return value1;
        }
        public String getValue2(){
            return value2;
        }        
        public String toString(){
            return value1+":"+value2+":"+value3+":"+id;
        }
    }
    //static 的內部類 不可讀取 外部類非靜態的任何東西
      static class StaticClass{
          private String name;
          public StaticClass(String name){
              this.name = name;
          }
         public String toString(){
             return name;
         }
    }
    
    void testClass(){
        //非靜態方法可以直接new
        NoneStatic ns = new NoneStatic(); 
    }
    
    
    
    public static void main(String[] args) {
      
      Ch6_5 c65 = new Ch6_5(81,"EK1527");
      Ch6_5.NoneStatic ns = c65.new NoneStatic(10,"Vivin");
      System.out.println(ns);
      
      Ch6_5.StaticClass stClass = new Ch6_5.StaticClass("Ken");
      System.out.println(stClass);
    }
    
}
