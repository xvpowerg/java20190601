/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public class Ch6_6 {
    private  class PrintSytle implements ForeachStyle{
            public void style(Object obj){
                System.out.println("value:"+obj);
            }
    }
    
      private  static  class PrintSytle2 implements ForeachStyle{
            public void style(Object obj){
                System.out.println("static:"+obj);
            }
    }
    
    public static void main(String[] args) {
      MyArray array = new MyArray(3);
      array.add("Ken");
      array.add("Vivin");
      array.add("Lindy");
      Ch6_6 c66 = new Ch6_6();
      //非靜態內部類用法
      array.foreach(c66.new PrintSytle());
      //靜態內部類用法
      array.foreach(new PrintSytle2());
      //匿名內部類
      array.foreach(new ForeachStyle(){
          public void style(Object obj){
              System.out.print("匿名:"+obj);
          }
      });
      System.out.println(".......");
      //lambda
      array.foreach((obj)->System.out.println("lambda:"+obj+" "));
      
    }
    
}
