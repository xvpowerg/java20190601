/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;
import java.util.Random;
/**
 *
 * @author howard
 */
public class Mouse implements Usb {
    private Random  radom = new Random();
    public void input(String v1){
        System.out.println(v1);
    }
    public String output(){
        return "x:"+radom.nextInt(1000) +" y:"+radom.nextInt(1000);
    }
}
