/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public interface Fly {
    //所有介面屬性都是靜態的且為常數
    int SEPPE_MAX = 500;
    void flying(int speed);
  //java 8特有的 預設方法
  
  public default void verifySpeed(int speed){
            if (speed > SEPPE_MAX){
                throw new IllegalArgumentException("速度不可大於:"+SEPPE_MAX);
            }
    }
 
}
