/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public class Ch6_3 implements TestIF3 {
    public void test(){
        System.out.println("test():");
    }
    public static void main(String[] args) {
      Ch6_3 c63 = new Ch6_3();
      c63.myDefault();
  
    }
    
}
