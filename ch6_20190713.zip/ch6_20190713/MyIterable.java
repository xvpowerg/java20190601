/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;
import java.util.Iterator;
//可以輪巡
@FunctionalInterface
public interface MyIterable {
   //輪巡工具
    Iterator iterator();
    public default void foreach(ForeachStyle fs){
         Iterator it =  iterator();
         while(it.hasNext()){            
             fs.style( it.next());
          //System.out.println(it.next());
         }
    }
}
