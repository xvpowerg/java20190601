/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

import java.util.Iterator;
import java.util.function.Predicate;
 class MyArrayIterator implements Iterator<String>{
     private MyArray tmpData;
     int index = -1;
     String nextValue;
     MyArrayIterator(MyArray data){
         tmpData = data;
     }
     
    public boolean hasNext(){
        nextValue = tmpData.get(++index);
        return nextValue != null;
    }
    public String next(){        
        return nextValue;
    }
}
public class MyArray implements MyIterable{
    private int size = 0;
    private int index = -1;
    private String[] data =null;
    MyArray(int size){
        this.size = size;
        data = new String[size];
    }    
    public boolean add(String value){
        if (index+1 >= size){
            return false;
        }
        data[++index] = value;
        return true;
    }  
    
    public String get(int index){
        if (index >= size){
            return null;
        }
        return data[index];
    }
    
    public String get(int index,Predicate<String>pd){
            String value =  get(index);
            if (pd.test(value)){
                return "通過";
            }else{
                return "未通過";
            } 
    }
    
    public Iterator iterator(){
        return new MyArrayIterator(this);
    }
    
    
//   public String[] getData(){
//       return data;
//   }
    
}
