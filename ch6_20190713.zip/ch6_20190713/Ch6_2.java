/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public class Ch6_2 {
    
    static void chocoboAction(ChockboAction action){
        action.attacking(100);
        action.flying(600);
        //IllegalArgumentException
        
        System.out.println(action.jumping());
    }
    
    public static void main(String[] args) {
        Chocobo chocobo1 = new Chocobo();
        chocoboAction(chocobo1);        
    }
    
}
