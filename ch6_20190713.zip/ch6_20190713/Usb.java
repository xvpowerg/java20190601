/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

//介面的所有一般方法都是public abstract
public interface Usb {
    //預設就是public abstract 
    void input(String data);
    String output();
    
}
