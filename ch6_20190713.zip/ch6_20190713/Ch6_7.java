/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public class Ch6_7 {
    
    public static void main(String[] args) {
      MyArray arra = new MyArray(1);
      arra.add("AB");
      System.out.println(
              arra.get(0, (st)->st.length()>=3));
      //Consumer<T>
      //Function<T,R>
      //Predicate<T>
      //Supplier<T>
      //UnaryOperator<T>  
      
    }
    
}
