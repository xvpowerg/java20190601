/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;
import java.util.Random;
/**
 *
 * @author howard
 */
//一個類別可以實作多個介面
//public class Chocobo implements Fly,Jump,Attack{
public class Chocobo implements ChockboAction{
    Random random = new Random();
   public void flying(int speed){
//       if (speed > Fly.SEPPE_MAX){
//           throw new IllegalArgumentException("Speed不可大於"+Fly.SEPPE_MAX);
//       }
       verifySpeed(speed);
       System.out.println("Speed:"+speed);
   } 
   public int jumping(){
       return random.nextInt(50);
   }
   public void attacking(int power){
       System.out.println("Poer:"+power);
   }
}
