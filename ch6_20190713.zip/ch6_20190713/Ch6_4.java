/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;
import java.util.Iterator;



public class Ch6_4 {

     static class PrintStyle implements ForeachStyle{
    public void style(Object obj){
        System.out.println("Name:"+obj);
    }
}
      static  class PrintStyle2 implements ForeachStyle{
    public void style(Object obj){
        System.out.print("Name:"+obj+" ");
    }
}
    
    public static void main(String[] args) {
            MyArray array = new MyArray(3);
            array.add("Ken");
            array.add("Vivin");
            array.add("Lindy");  
            array.foreach(new PrintStyle());            
            array.foreach(new PrintStyle2());
            
           
//            Iterator it =  array.iterator();
//            while(it.hasNext()){
//                System.out.println(it.next());
//            }
           

//          }
    }
    
}
