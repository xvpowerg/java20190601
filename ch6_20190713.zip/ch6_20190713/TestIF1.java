/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public interface TestIF1 {
    //抽象與Static 的介面方法 多重繼承時，重複方法名稱
    //default 的介面方法  多重繼承時時不可重複方法名稱
    void test();
    public default void myDefault(){
        System.out.println("TestIF1...");
    }
    static void myStatic(){
        System.out.println("TestIF1 myStatic...");
    }
    
}
