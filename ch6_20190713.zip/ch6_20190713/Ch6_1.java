/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190713;

/**
 *
 * @author howard
 */
public class Ch6_1 {
    
    
    static void usbHub(Usb usb){        
        for(int i = 1;i<=10;i++){
            usb.input("5v");
            System.out.println(usb.output());            
        }        
    }
    
    public static void main(String[] args) {         
        //介面
        Usb mouse = new Mouse();
        usbHub(mouse);
    }
    
}
