/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class Ch3_5 {
    public static void main(String[] args){
        
        //boolean boxing
        Boolean b1 = Boolean.valueOf(true);
        //boolean unboxing
        System.out.println(b1.booleanValue());
        //Boolean.parseBoolean只要是true沒有空格或其他符號，不分大小寫都可正確parse為true
        //其他都parse為false        
        boolean b2 = Boolean.parseBoolean("true");
        System.out.println(b2);
       boolean b3 = Boolean.parseBoolean("True");
        System.out.println(b3);  
       boolean b4 = Boolean.parseBoolean("TrUe");
        System.out.println(b4);  
        
        boolean b5 = Boolean.parseBoolean("asdasdas");
        System.out.println(b5);  
    }
}
