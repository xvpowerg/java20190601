/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;


public class Ch3_4 {

    public static void main(String[] args) {
      //寄送包裹 
        // 封箱 boxing
          //標準化
          //保護產品
          //封箱只有特定情況下才需要
          
      //收到包裹 unboxing
         //開箱
   
        // 封箱 boxing
        //手動
        //只有基本型態需要Boxing
        //byte  Byte
        //short Short
        //int Integer
        //long Long
        //float Float
        //double Double
        //char Character
        //boolean Boolean
        
         int value1 = 81;
         //手動Boxing (裝箱)
        Integer intBox = Integer.valueOf(value1);
        //開箱動作
        int myValue = intBox.intValue();        
        //System.out.println(myValue);
        
        Integer box1 = Integer.valueOf(185);
        Integer box2 = Integer.valueOf(185);
        //如果要比較2個非基本型態，要使用equals
        //使用 == 比較是有風險的 ，他比較的是兩變數內的記憶體位置是否相等
        System.out.println(box1 == box2);
        System.out.println(box1.equals(box2));
        //cache -128~127  1 byte
        Integer box3 = Integer.valueOf(127);
        Integer box4 = Integer.valueOf(127);   
        System.out.println("box3==box4:"+ (box3 == box4));
        //文字變數字
        String s1 = "256";
        int intValue = Integer.parseInt(s1);
        intValue += 2;
        System.out.println(intValue);
        
        String s2 = "2 56";
       // int intValue2 = Integer.parseInt(s2);//拋出例外NumberFormatException.java
          //System.out.println(intValue2);
          
          //10 to 2 
            String bStr = Integer.toBinaryString(13);
            System.out.println(bStr);
            char[] charAray = bStr.toCharArray();            
            for (char n1 :  charAray){
                System.out.println(n1 - '0');                
            }
          //10 to 8 
            String oStr = Integer.toOctalString(25);
            System.out.println(oStr);
          //10 to 16
           String hStr = Integer.toHexString(171);
          System.out.println(hStr);
        
    }
    
}
