/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class C3_1 {
    
    static int pow(int n,int value){
        int result = 1;
        for(int i =1; i<= n;i++){
            result *= value;
        }
        return result;
    }
    
    public static void main(String[] args) {
       int a = 10;
       int b = 70;
        
        System.out.println(pow(2,3));
        
    }
    
}
