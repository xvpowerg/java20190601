/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

public class Ch3_3 {
    //vargs 0到多個參數
    //vargs 唯一的限制是 必須是參數的最後一個位置
   static void testVargs(float v1,String v2,int ... vs){
       
   }
        static int sum(int ... prices){
            int sum = 0;
            for (int p : prices){
                sum += p;
            }
            return sum;
        } 
    public static void main(String[] args) {
      System.out.printf("%d %s %f %n",10,"K",1.56f);
      
        System.out.println(sum(1,6,7,8,1,2,3,4,5));
        
    }
    
}
