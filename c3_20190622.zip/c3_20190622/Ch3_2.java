/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;
public class Ch3_2 {
    static void testMyRecursion(int n){        
        if (n <= 5){
            System.out.println(n);
           testMyRecursion(n+1); 
        }        
        System.out.println(n);
    }    
    //階乘
    static int factorial(int n){
        if (n <= 1){return 1;}
        return factorial(n - 1) * n;
    }
    
    
    public static void main(String[] args){
        //1 ~ 5
        //不用迴圈 遞迴來寫
       // testMyRecursion(1);       
       System.out.println(factorial(5));
    }
}
