/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class Ch3_6 {
   
     public static void main(String[] args){
         //auto boxing
         Integer boxing = 12;
         //auto unboxing
         int value = boxing;
         //throw NullPointerException
         //Integer boxing2 = null; 
         //int value2 =  boxing2;
         
         Integer boxing3 = 51;
         int vlaue3 = 2 + boxing3;
         System.out.println(vlaue3);
         
         Integer boxing4 = null;
         int vlaue4 = 2;
         if (boxing4 != null){
             vlaue4 = 2 + boxing4;
         }         
         System.out.println(vlaue4);
         
     }
}
