/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class Ch3_7 {
    //Overloding 多載
    //方名稱要一樣，參數的數量或類型不一樣
    //自動呼叫相對映參數的方法
    //Overloding呼叫規則
    //先找一樣類型
    //相同類型可相容
    //不同類型可相容
    //封箱類型 
  
    static String merge(String s1,String s2){
        return s1 + s2;
    }
    static String merge(int v1,int v2){
        return String.valueOf(v1) + String.valueOf(v2);
    }
    
    static void test1(int v1){
        System.out.println("test1 int");
    }
    static void test1(float v2){
        System.out.println("test1 float");
    }
    
  static void test2(byte v1){
        System.out.println("test2 byte");
    }
    static void test2(float v2){
        System.out.println("test2 float");
    }
    
    static void test3(int v1,float f1){
        System.out.println("test3 int float");
    }
    
    static void test3(int v1,byte b1){
        System.out.println("test3 int byte");
    }
    
      static void test4(int v1,float f1){
        System.out.println("test4 int float");
    }
    
    static void test4(int v1,Integer b1){
        System.out.println("test4 int Integer");
    }
    
     static void test5(int v1,Float f1){
        System.out.println("test5 int Float");
    }
    
    static void test5(int v1,Integer b1){
        System.out.println("test5 int Integer");
    }
    //當參數是一個以上時，要注意必須至少一個參數是完全配對的
    
   static void test6(int v1,float f1){
        System.out.println("int float");
    }
    
    static void test6(float f1,int v1){
        System.out.println("float int");
    }
    
   static void test7(int v1,int ... v2){
        System.out.println("int int ...");
    }
    
   static void test7(int f1,int v1,int v3){
        System.out.println("int int int");
    }
       static void test8(int v1,float f1,int s1){
        System.out.println("int float");
    }
    
    static void test8(float f1,int v1,double d1){
        System.out.println("float int");
    }
    public static void main(String[] args){
     
//        System.out.println(merge("Value1","Value2"));
//        System.out.println(merge("Value1","Value2"));        
//        System.out.println(merge("Value1","Value2"));
//        System.out.println(merge(25,31));
    //test1(20);//顯示test1 int
    //test2(10);//10的類型是整數所以 不相容於byte 於是往float運行
    //test3(2,5);
    //test4(7,8);
   // test5(7,8);
  // test6(1,6f);
  test7(5);
  test7(5,6,7,8,9);
  test7(5,6,7);
    }
}
