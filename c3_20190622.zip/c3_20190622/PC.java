/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class PC {
    //屬性
   private String cpu;
    String graphicsCard;
    private int memory;
    String hd; 
    //Constructor 建構式
    // 沒有回傳值 方法名稱跟類別一樣
    //當沒有Constructor時會預設建立一組沒參數的Constructor
    //如果有自定義Constructor時預設建構子會消失
    
  //default Constructor
    PC(){
        //this()可以呼叫另一組建構子
        //this() 只能在建構子內呼叫
        //只能是第一行命令
        this("未設定CPU",   "未設定graphicsCard",0, "未設定hd");
    }
    //other Constructor
    PC(String cpu,  String graphicsCard,int memory, String hd){
        this.cpu = cpu;
        this.graphicsCard = graphicsCard;
        this.memory = memory;
        this.hd =  hd;
    }
    public void setMemory(int memory){
        if (memory < 4 || memory > 512){
            System.out.println("錯誤的 Memory");
            return;
        }   
        //this表示目前的物件
        this.memory = memory;
    }
     public int getMemory(){
        return  memory;
    }
    //存錢
    public void setCpu(String inCpu){
        //trim() 去除空白
        if (inCpu == null || inCpu.trim().length() ==0){
            System.out.println("錯誤的cpu");            
            //離開方法
            return;
        }
        
        cpu =inCpu;
    }
    //領錢
    public String getCpu(){
        return cpu;
    }
    
   void print(){
        System.out.println(cpu+":"+memory+
                         ":"+graphicsCard+":"+hd);
   }
    
}
