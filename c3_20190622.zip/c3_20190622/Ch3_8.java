/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3_20190622;

/**
 *
 * @author howard
 */
public class Ch3_8 {
    
    public static void main(String[] args) {
        //先有類別才有物件
        //寫類別做的事 把相同規格與類型整合再一起
        //規格 類內稱為屬性 
        
        PC myPc = new PC();
        //cpu 不可為null 也不可為empty
        //myPc.cpu = null;
        myPc.setCpu(null);
        //請封裝memory
        //檢查條件是:不可小於4 大於512
        myPc.setMemory(16);
        myPc.graphicsCard = "1080TI";
        myPc.hd = "1T SSD";        
        myPc.print();
        System.out.println(myPc.getCpu());
         //封裝Encapsulation 
         //私有的屬性
         //公開的窗口
        PC myPc2 = new PC();
       // myPc2.cpu = "Intel i9";
        myPc2.setCpu("Intel i9");
        myPc2.setMemory(32) ;
        myPc2.graphicsCard = "2070TI";
        myPc2.hd = "512G SSD";  
      myPc2.print();
      
         PC myPc3 = new PC("Intel i5","1060",8,"512G SSD");
         myPc3.print();
         
         PC myPc4 = new PC();  
         myPc4.print();
    }
    
}
