/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 *
 * @author howard
 */
public class Ch11_2 {

     static Student genStudent(String msg){
        String[] st1  = msg.split(",");
        Student stu = new Student(st1[0],
                Integer.parseInt(st1[1]));
        return stu;
    }
    public static void main(String[] args) {
         List<String> list = new ArrayList<>();
       list.add("Ken,60");
       list.add("Vivin,75");
       list.add("Lindy,60");
       list.add("Gigi,52");
       list.add("Iris,25");
       list.add("Iris,68");
       //list.stream().collect(Collectors.toCollection(collectionFactory));
        Comparator<Student> stCmp = Comparator.<Student>comparingInt(st->st.getScore()).
                thenComparing( st->st.getName() );
        
//     TreeSet set =  list.stream().map(Ch11_2::genStudent).
//              collect(Collectors.toCollection(()-> new TreeSet<Student>(stCmp)));
//     set.forEach(System.out::println);
//     Map<String,Student> stMap =   list.stream().map(Ch11_2::genStudent).collect(
//                Collectors.toMap(st->st.getName(), st->st));
//     System.out.println(stMap);
      
//       Map<String,Student> stMap = list.stream().map(Ch11_2::genStudent).
//               collect(Collectors.
//                       toMap(st->st.getName(), 
//                            st->st, 
//                            (oSt,nSt)->new Student(oSt.getName(),
//                                       oSt.getScore() +nSt.getScore()) ,
//                            TreeMap::new)   
//                );
//       
//       System.out.println(stMap);


//      Map<Integer,List<Student>>  groupMap =   
//              list.stream().map(Ch11_2::genStudent).collect(
//                   Collectors.groupingBy(st->st.getScore() / 10 ) );
//     
//           groupMap.forEach((k,v)->{
//           
//               System.out.println(k+":"+v);           
//           });
//    Map<Integer,Map<Integer,List<Student>>> obj =  
//               list.stream().map(Ch11_2::genStudent).collect(
//                       Collectors.groupingBy(st->st.getScore()/10,                                 
//                       Collectors.groupingBy(st->st.getName().length()))
//                               );
//       System.out.println(obj);
       
//   Map<Boolean,List<Student>> parMap =   
//           list.stream().map(Ch11_2::genStudent).collect(
//              Collectors.partitioningBy(st->st.getScore() >= 60));
//   System.out.println(parMap);
   
    String joining =    list.stream().map((st)->st.split(",")[0]).
               collect(Collectors.joining(","));
    System.out.println(joining);
      String joining2 =list.stream().map((st)->st.split(",")[0]).
               collect(Collectors.joining(",", "姓名:", "‧"));
      System.out.println(joining2);
      

      
    }
    
}
