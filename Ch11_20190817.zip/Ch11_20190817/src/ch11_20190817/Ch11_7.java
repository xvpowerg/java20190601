/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
/**
 *
 * @author howard
 */
public class Ch11_7 {

   
    public static void main(String[] args) {
      File srcFIle = new File("c:\\javadir\\myzip.zip");
      File copyFIle = new File("c:\\javadir\\myzip_copy.zip");
        
      try(InputStream ins = new FileInputStream(srcFIle);
          OutputStream outs = new FileOutputStream(copyFIle);  ){
          double start = System.currentTimeMillis();
          byte[] buffer  = new byte[1024 * 1024];
          int index = -1;
          while ( (index = ins.read(buffer)) != -1 ){
              outs.write(buffer, 0, index);
          }
          System.out.println((System.currentTimeMillis() - start) / 1000 );
          
      }catch(IOException ex){
          System.out.println(ex);
      }
    }
    
}
