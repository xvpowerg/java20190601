/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ch11_6 {

    public static void main(String[] args) {
      File srcFIle = new File("c:\\javadir\\myzip.zip");
      File copyFIle = new File("c:\\javadir\\myzip_copy.zip");
        
        try(BufferedInputStream bfIn = 
            new BufferedInputStream(new FileInputStream(srcFIle));
           BufferedOutputStream bfOut= 
                   new BufferedOutputStream(new FileOutputStream(copyFIle))){            
           int data =-1;
           while( (data = bfIn.read()) != -1){
               bfOut.write(data);
           }
            
        }catch(IOException ex){
            System.out.println(ex);
        }
    }
    
}
