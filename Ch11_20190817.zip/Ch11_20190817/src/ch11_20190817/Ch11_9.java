/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch11_9 {
    public static void main(String[] args) {
        //序列化
      String value = "Ken";
        File file = new File("c:\\javadir\\value.dao");
        
        try(FileOutputStream fileOut = new FileOutputStream(file);
             ObjectOutputStream oOut = new   ObjectOutputStream(fileOut); ){
            oOut.writeObject(value);            
        }catch(IOException ex){
            System.out.println(ex);
        }
        
        
        
    }
    
}
