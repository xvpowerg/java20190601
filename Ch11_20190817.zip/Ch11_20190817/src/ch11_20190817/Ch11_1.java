/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author howard
 */
public class Ch11_1 {
    private static Student genStudent(String msg){
        String[] st1  = msg.split(",");
        Student stu = new Student(st1[0],
                Integer.parseInt(st1[1]));
        return stu;
    }
    public static void main(String[] args) {       
       List<String> list = new ArrayList<>();
       list.add("Ken,60");
       list.add("Vivin,75");
       list.add("Lindy,83");
        
//       list.stream().map(Ch11_1::genStudent).
//               forEach(System.out::println);
        
      List<Student> stList =
              list.stream().map(Ch11_1::genStudent).collect(Collectors.toList());
      stList.forEach(System.out::println);
      
      Student st1 = new Student("Gigi",90);    
      st1.getHobby().forEach(System.out::println);
      
    }
    
}
