/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
public class Ch11_8 {

    public static void main(String[] args) {
       File file = new File("c:\\javadir\\newsx.txt");
       try( FileReader fr = new FileReader(file);){           
           int myChar = -1;           
          while( (myChar = fr.read()) != -1 ){
               System.out.print((char) myChar);
           }          
       }catch(IOException ex){
           System.out.println(ex);
       }

        
        
        
    }
    
}
