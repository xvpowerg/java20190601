/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 *
 * @author howard
 */
public class Ch11_3 {

    public static void main(String[] args) {
        Item i1 = new Item("iPhone7");
        i1.apendDes("超大螢幕");
        i1.apendDes("A7CPU");
        
        Item i2 = new Item("DLink");
        i1.apendDes("自動防毒");
        i1.apendDes("快速連線");
        
        ArrayList<Item> list = new ArrayList<>();
        list.add(i1);
        list.add(i2);
        
       String des =  list.stream().flatMap((st)->st.getDes().stream()).
                collect(Collectors.joining("\n", "產品描述\n", "."));
       System.out.println(des);

    }
    
}
