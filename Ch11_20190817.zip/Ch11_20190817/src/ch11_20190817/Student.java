/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 *
 * @author howard
 */
public class Student {
    private String name;
    private int score;
    private List<String> hobbys = new ArrayList<>();
    
    public Student(String name, int score) {
        this.name = name;
        this.score = score;
        hobbys.add("閱讀");
        hobbys.add("音樂");
        hobbys.add("打球");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
   //唯讀 
    public Stream<String> getHobby(){      
        return hobbys.stream();
    }

    @Override
    public String toString() {
        return  "name=" + name + ", score=" + score ;
    }
    
}
