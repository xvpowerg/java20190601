/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author howard
 */
public class Item {
    private String name;
    private List<String> des;
    public Item(String name){
        this.name = name;
        des = new ArrayList<>();
    }
    
    public List<String> getDes(){
        return des;
    }
    public void apendDes(String desMsg){
        des.add(desMsg);
    }
    public String getName(){
        return name;
    }
}
