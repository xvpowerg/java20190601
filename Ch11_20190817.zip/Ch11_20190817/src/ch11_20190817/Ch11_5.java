/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20190817;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch11_5 {

    public static void main(String[] args) {
      File srcFIle = new File("c:\\javadir\\myzip.zip");
      File copyFIle = new File("c:\\javadir\\myzip_copy.zip");
       InputStream instr = null;
      OutputStream outStr = null;
      try{
          instr =  new FileInputStream(srcFIle);  
         instr = new BufferedInputStream(instr);
         outStr = new FileOutputStream(copyFIle);
         outStr = new BufferedOutputStream(outStr);
         int data = -1;
         double start =   System.currentTimeMillis();
         System.out.println("開始");
         while( (data = instr.read())!=-1 ){
             outStr.write(data);             
         }
         System.out.println("完成");
         System.out.println( (System.currentTimeMillis() - start ) / 1000 );
         
      }catch(FileNotFoundException ex){
          System.out.println(ex);
      }catch(IOException ex){
          System.out.println(ex);
      }finally{
          try{
              outStr.close();
                instr.close();
          }catch(IOException ex){
              System.out.println(ex);
          }
          
      }
     
        
        
    }
    
}
